-- Agile Scrum 演示库表结构（MySQL 8，utf8mb4）
-- 首次启动空数据卷时由 docker-entrypoint-initdb.d 自动执行

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `user` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(64) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(32) NOT NULL,
  `email` VARCHAR(128) DEFAULT NULL,
  `nickname` VARCHAR(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `project` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `description` VARCHAR(1024) DEFAULT NULL,
  `owner_id` BIGINT DEFAULT NULL,
  `created_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sprint` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `description` VARCHAR(1024) DEFAULT NULL,
  `start_date` DATE DEFAULT NULL,
  `end_date` DATE DEFAULT NULL,
  `status` VARCHAR(32) NOT NULL DEFAULT 'PLANNING',
  `project_id` BIGINT NOT NULL,
  `total_story_points` INT DEFAULT NULL,
  `goal` VARCHAR(512) DEFAULT NULL,
  `capacity` INT DEFAULT NULL,
  `created_at` DATETIME DEFAULT NULL,
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sprint_project` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `story` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `project_id` BIGINT DEFAULT NULL,
  `sprint_id` BIGINT DEFAULT NULL,
  `title` VARCHAR(512) NOT NULL,
  `story_point` INT DEFAULT NULL,
  `status` VARCHAR(32) DEFAULT 'TODO',
  `description` TEXT,
  `priority` VARCHAR(32) DEFAULT 'MEDIUM',
  `create_time` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_story_sprint` (`sprint_id`),
  KEY `idx_story_project` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `task` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(512) NOT NULL,
  `description` TEXT,
  `priority` VARCHAR(32) DEFAULT 'MEDIUM',
  `status` VARCHAR(32) NOT NULL DEFAULT 'TODO',
  `assignee_id` INT DEFAULT NULL,
  `story_points` INT DEFAULT NULL,
  `sprint_id` INT DEFAULT NULL,
  `story_id` INT DEFAULT NULL,
  `created_at` DATETIME DEFAULT NULL,
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_task_sprint` (`sprint_id`),
  KEY `idx_task_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `scrum_event` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `sprint_id` BIGINT NOT NULL,
  `user_id` BIGINT NOT NULL,
  `type` VARCHAR(32) NOT NULL,
  `content` TEXT,
  `blockers` TEXT,
  `created_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sprint` (`sprint_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
