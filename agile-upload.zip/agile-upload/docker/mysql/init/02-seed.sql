-- 演示数据：账号密码均为 password（BCrypt）
-- 与 jBCrypt / Spring PasswordUtil 兼容

SET NAMES utf8mb4;

-- ========== 用户（6 个演示账号）==========
INSERT INTO `user` (`id`, `username`, `password`, `role`, `email`, `nickname`) VALUES
(1, 'demo_po', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'PRODUCT_OWNER', 'po@demo.local', '产品负责人'),
(2, 'demo_sm', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'SCRUM_MASTER', 'sm@demo.local', 'Scrum Master'),
(3, 'demo_dev', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'DEVELOPER', 'dev@demo.local', '后端开发'),
(4, 'demo_dev2', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'DEVELOPER', 'dev2@demo.local', '全栈开发'),
(5, 'demo_qa', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'DEVELOPER', 'qa@demo.local', '测试'),
(6, 'demo_fe', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'DEVELOPER', 'fe@demo.local', '前端开发');

-- ========== 项目 ==========
INSERT INTO `project` (`id`, `name`, `description`, `owner_id`, `created_at`) VALUES
(1, '星云电商平台', '订单、支付、会员与营销中台敏捷交付', 1, NOW()),
(2, '移动 App 会员中心', '积分、等级、权益与 Push 触达', 1, DATE_SUB(NOW(), INTERVAL 30 DAY)),
(3, '数据中台 BI', '报表、指标口径与可视化大屏', 2, DATE_SUB(NOW(), INTERVAL 14 DAY));

-- ========== 迭代 ==========
INSERT INTO `sprint` (`id`, `name`, `description`, `start_date`, `end_date`, `status`, `project_id`, `total_story_points`, `created_at`, `updated_at`) VALUES
(1, 'Sprint 12 · 支付与结算', '完成微信/支付宝对接与对账 MVP',
 DATE_SUB(CURDATE(), INTERVAL 7 DAY), DATE_ADD(CURDATE(), INTERVAL 7 DAY),
 'ACTIVE', 1, 40, NOW(), NOW()),
(2, 'Sprint 13 · 会员成长体系', '等级规则与积分商城一期',
 DATE_ADD(CURDATE(), INTERVAL 3 DAY), DATE_ADD(CURDATE(), INTERVAL 17 DAY),
 'PLANNING', 1, 28, NOW(), NOW()),
(3, 'Sprint 8 · App 签到与任务', '日签、周任务与消息触达',
 DATE_SUB(CURDATE(), INTERVAL 5 DAY), DATE_ADD(CURDATE(), INTERVAL 9 DAY),
 'ACTIVE', 2, 32, NOW(), NOW()),
(4, 'Sprint 7 · BI 看板 MVP', '核心指标与权限模型',
 DATE_SUB(CURDATE(), INTERVAL 21 DAY), DATE_SUB(CURDATE(), INTERVAL 1 DAY),
 'COMPLETED', 2, 24, NOW(), NOW()),
(5, 'Sprint 1 · 数据口径治理', '指标字典与血缘初版',
 DATE_ADD(CURDATE(), INTERVAL 7 DAY), DATE_ADD(CURDATE(), INTERVAL 28 DAY),
 'PLANNING', 3, 20, NOW(), NOW());

-- ========== 用户故事：Backlog（未进 Sprint）==========
INSERT INTO `story` (`id`, `project_id`, `sprint_id`, `title`, `story_point`, `status`, `description`, `priority`, `create_time`) VALUES
(1, 1, NULL, '优惠券体系一期', 13, 'TODO', '满减券与领取记录', 'HIGH', DATE_SUB(NOW(), INTERVAL 10 DAY)),
(2, 1, NULL, '商品搜索优化', 8, 'TODO', '同义词与纠错', 'MEDIUM', DATE_SUB(NOW(), INTERVAL 8 DAY)),
(3, 3, NULL, '运营数据看板', 5, 'TODO', '核心 KPI 卡片', 'LOW', DATE_SUB(NOW(), INTERVAL 5 DAY)),
(6, 1, NULL, '秒杀库存预热', 8, 'TODO', 'Redis 与 DB 一致性', 'HIGH', NOW()),
(7, 1, NULL, '售后工单 SLA', 5, 'TODO', '超时升级与通知', 'MEDIUM', NOW()),
(8, 2, NULL, '多语言文案管理', 5, 'TODO', 'i18n 资源与发布', 'LOW', NOW()),
(9, 1, NULL, '发票与税务对接', 13, 'TODO', '专票/普票与红冲', 'HIGH', NOW()),
(10, 1, NULL, '推荐算法 A/B', 8, 'TODO', '实验分流与指标', 'MEDIUM', NOW()),
(11, 1, NULL, '物流轨迹订阅', 5, 'TODO', 'Webhook 与补偿', 'MEDIUM', NOW()),
(12, 1, NULL, '商家结算账单', 13, 'TODO', '对账周期与争议', 'HIGH', NOW()),
(13, 1, NULL, '内容安全审核', 8, 'TODO', '敏感词与人工复核', 'HIGH', NOW()),
(14, 2, NULL, '小程序码与分享', 3, 'TODO', '渠道参数统计', 'LOW', NOW()),
(15, 2, NULL, '灰度发布策略', 5, 'TODO', '按用户/地域放量', 'MEDIUM', NOW());

-- ========== Sprint 1 内故事 ==========
INSERT INTO `story` (`id`, `project_id`, `sprint_id`, `title`, `story_point`, `status`, `description`, `priority`, `create_time`) VALUES
(4, 1, 1, '支付网关对接', 8, 'DOING', '统一下单与回调', 'HIGH', DATE_SUB(NOW(), INTERVAL 6 DAY)),
(5, 1, 1, '订单状态机梳理', 5, 'TODO', '待支付/已支付/退款', 'HIGH', DATE_SUB(NOW(), INTERVAL 6 DAY)),
(16, 1, 1, '签约代扣协议', 5, 'DONE', '协议页与签约记录', 'MEDIUM', DATE_SUB(NOW(), INTERVAL 5 DAY)),
(17, 1, 1, '支付结果页 UX', 3, 'DONE', '成功/失败引导', 'LOW', DATE_SUB(NOW(), INTERVAL 4 DAY)),
(18, 1, 1, '风控规则初版', 8, 'DOING', '限额与黑名单', 'HIGH', NOW()),
(19, 1, 1, '渠道手续费配置', 5, 'TODO', '运营可配费率表', 'MEDIUM', NOW());

-- ========== Sprint 2（规划中）故事 ==========
INSERT INTO `story` (`id`, `project_id`, `sprint_id`, `title`, `story_point`, `status`, `description`, `priority`, `create_time`) VALUES
(20, 1, 2, '会员等级计算', 8, 'TODO', '成长值与保级', 'HIGH', NOW()),
(21, 1, 2, '积分商城货架', 5, 'TODO', 'SKU 与库存', 'MEDIUM', NOW()),
(22, 1, 2, 'Push 模板中心', 5, 'TODO', '变量与频控', 'MEDIUM', NOW());

-- ========== Sprint 3（App 会员 · 进行中）故事 ==========
INSERT INTO `story` (`id`, `project_id`, `sprint_id`, `title`, `story_point`, `status`, `description`, `priority`, `create_time`) VALUES
(23, 2, 3, '签到日历与补签', 5, 'DONE', '连续签到奖励', 'HIGH', DATE_SUB(NOW(), INTERVAL 4 DAY)),
(24, 2, 3, '周任务进度条', 8, 'DOING', '任务链与领奖', 'HIGH', NOW()),
(25, 2, 3, '消息中心 Inbox', 5, 'TODO', '已读/聚合', 'MEDIUM', NOW()),
(26, 2, 3, '埋点 SDK 升级', 5, 'DOING', '曝光与点击', 'MEDIUM', NOW()),
(27, 2, 3, '隐私合规弹窗', 3, 'TODO', '首次启动与设置', 'LOW', NOW());

-- ========== Sprint 4（已结束）故事 ==========
INSERT INTO `story` (`id`, `project_id`, `sprint_id`, `title`, `story_point`, `status`, `description`, `priority`, `create_time`) VALUES
(28, 2, 4, '指标字典表', 8, 'DONE', '口径与负责人', 'HIGH', DATE_SUB(NOW(), INTERVAL 25 DAY)),
(29, 2, 4, '报表权限模型', 8, 'DONE', '行级/列级', 'HIGH', DATE_SUB(NOW(), INTERVAL 24 DAY)),
(30, 2, 4, '看板拖拽布局', 5, 'DONE', '保存个人视图', 'MEDIUM', DATE_SUB(NOW(), INTERVAL 23 DAY));

-- ========== Sprint 5 故事 ==========
INSERT INTO `story` (`id`, `project_id`, `sprint_id`, `title`, `story_point`, `status`, `description`, `priority`, `create_time`) VALUES
(31, 3, 5, '血缘采集 PoC', 8, 'TODO', 'SQL 解析与图', 'HIGH', NOW()),
(32, 3, 5, '数据质量规则', 5, 'TODO', '空值与波动', 'MEDIUM', NOW());

-- ========== 任务（Sprint 1：支付迭代，丰富看板）==========
INSERT INTO `task` (`title`, `description`, `priority`, `status`, `assignee_id`, `story_points`, `sprint_id`, `story_id`, `created_at`, `updated_at`) VALUES
('支付渠道：微信 SDK 集成', '配置商户号与证书', 'HIGH', 'DONE', 3, 8, 1, 4, NOW(), DATE_SUB(NOW(), INTERVAL 6 DAY)),
('支付渠道：支付宝当面付', '扫码与异步通知', 'HIGH', 'DONE', 3, 5, 1, 4, NOW(), DATE_SUB(NOW(), INTERVAL 4 DAY)),
('对账文件解析', 'CSV 导入与差异标记', 'MEDIUM', 'DOING', 4, 5, 1, 4, NOW(), NOW()),
('订单退款接口', '幂等与风控校验', 'HIGH', 'DOING', 3, 8, 1, 5, NOW(), NOW()),
('结算批次任务', '定时汇总与推送', 'MEDIUM', 'TODO', 5, 5, 1, 5, NOW(), NOW()),
('监控告警接入', '支付失败率阈值', 'LOW', 'TODO', 6, 9, 1, NULL, NOW(), NOW()),
('签约页 H5 联调', '银行签约跳转', 'HIGH', 'DONE', 4, 5, 1, 16, NOW(), DATE_SUB(NOW(), INTERVAL 3 DAY)),
('支付结果页埋点', '曝光/点击', 'MEDIUM', 'DONE', 6, 3, 1, 17, NOW(), DATE_SUB(NOW(), INTERVAL 2 DAY)),
('风控名单同步 Job', '定时拉取与缓存', 'HIGH', 'DOING', 3, 5, 1, 18, NOW(), NOW()),
('费率配置后台 CRUD', '运营表单校验', 'MEDIUM', 'TODO', 5, 5, 1, 19, NOW(), NOW()),
('渠道对账差异报表', '导出 Excel', 'MEDIUM', 'DOING', 4, 3, 1, 4, NOW(), NOW()),
('支付超时关单', '定时任务与补偿', 'HIGH', 'TODO', 3, 5, 1, 5, NOW(), NOW());

-- ========== 任务（Sprint 3：App 会员）==========
INSERT INTO `task` (`title`, `description`, `priority`, `status`, `assignee_id`, `story_points`, `sprint_id`, `story_id`, `created_at`, `updated_at`) VALUES
('签到 UI 与动画', '连续签到动效', 'HIGH', 'DONE', 6, 3, 3, 23, NOW(), DATE_SUB(NOW(), INTERVAL 5 DAY)),
('补签券消耗逻辑', '库存与扣减', 'HIGH', 'DONE', 3, 2, 3, 23, NOW(), DATE_SUB(NOW(), INTERVAL 4 DAY)),
('周任务配置接口', '后台配置', 'HIGH', 'DOING', 3, 5, 3, 24, NOW(), NOW()),
('任务领奖接口', '幂等领奖', 'MEDIUM', 'DOING', 4, 3, 3, 24, NOW(), NOW()),
('Inbox 列表接口', '分页与已读', 'MEDIUM', 'TODO', 5, 3, 3, 25, NOW(), NOW()),
('埋点 batch 上报', '失败重试', 'MEDIUM', 'DOING', 3, 2, 3, 26, NOW(), NOW()),
('合规弹窗文案', '多语言', 'LOW', 'TODO', 6, 2, 3, 27, NOW(), NOW()),
('Push 到达率统计', '报表 SQL', 'MEDIUM', 'DONE', 5, 3, 3, 24, NOW(), DATE_SUB(NOW(), INTERVAL 1 DAY));

-- ========== 任务（Sprint 4：BI 已结束，供燃尽图有数据；与 story 28-30 对应）==========
INSERT INTO `task` (`title`, `description`, `priority`, `status`, `assignee_id`, `story_points`, `sprint_id`, `story_id`, `created_at`, `updated_at`) VALUES
('指标字典表 API', '口径 CRUD', 'HIGH', 'DONE', 3, 8, 4, 28, NOW(), DATE_SUB(NOW(), INTERVAL 20 DAY)),
('报表权限拦截器', '行级过滤', 'HIGH', 'DONE', 3, 8, 4, 29, NOW(), DATE_SUB(NOW(), INTERVAL 18 DAY)),
('看板布局保存', '用户视图 JSON', 'MEDIUM', 'DONE', 6, 5, 4, 30, NOW(), DATE_SUB(NOW(), INTERVAL 16 DAY));

-- ========== 任务（Sprint 2：仅规划，少量占位）==========
INSERT INTO `task` (`title`, `description`, `priority`, `status`, `assignee_id`, `story_points`, `sprint_id`, `story_id`, `created_at`, `updated_at`) VALUES
('等级规则表设计', 'ER 与评审', 'HIGH', 'TODO', 2, 3, 2, 20, NOW(), NOW()),
('积分商城 PRD 评审', '范围确认', 'MEDIUM', 'TODO', 1, 2, 2, 21, NOW(), NOW()),
('Push 模板变量引擎', '频控与占位符', 'MEDIUM', 'TODO', 3, 5, 2, 22, NOW(), NOW());

-- ========== 任务（Sprint 5：BI 规划中，与 story 31-32 对应；否则燃尽图为 0）==========
INSERT INTO `task` (`title`, `description`, `priority`, `status`, `assignee_id`, `story_points`, `sprint_id`, `story_id`, `created_at`, `updated_at`) VALUES
('SQL 血缘解析 PoC', '解析器与图存储', 'HIGH', 'TODO', 3, 8, 5, 31, NOW(), NOW()),
('质量规则 DSL 草案', '空值/波动阈值', 'MEDIUM', 'TODO', 4, 5, 5, 32, NOW(), NOW());

-- ========== 站会 / 评审 / 回顾 ==========
INSERT INTO `scrum_event` (`sprint_id`, `user_id`, `type`, `content`, `blockers`, `created_at`) VALUES
(1, 3, 'STANDUP', '昨日完成微信 SDK；今日联调支付宝；风险：沙箱不稳定', '无', DATE_SUB(NOW(), INTERVAL 4 DAY)),
(1, 3, 'STANDUP', '对账解析 80%；今日补单元测试', '依赖测试数据', DATE_SUB(NOW(), INTERVAL 3 DAY)),
(1, 4, 'STANDUP', '签约页联调通过；今日跟埋点', '无', DATE_SUB(NOW(), INTERVAL 2 DAY)),
(1, 1, 'REVIEW', '演示支付闭环与失败重试；PO 接受当前范围', '对账精度待下期', DATE_SUB(NOW(), INTERVAL 1 DAY)),
(1, 2, 'RETRO', '沟通顺畅；改进：提前约定接口契约', '无', NOW()),
(3, 3, 'STANDUP', '周任务后端 50%；今日补前端状态机', '无', DATE_SUB(NOW(), INTERVAL 2 DAY)),
(3, 6, 'STANDUP', '签到动效调参；今日联调领奖', '无', DATE_SUB(NOW(), INTERVAL 1 DAY)),
(3, 2, 'REVIEW', 'App 端演示通过，Push 下期做', '埋点需补全', NOW()),
(4, 2, 'RETRO', 'BI 迭代按时交付；下迭代加强测试左移', '无', DATE_SUB(NOW(), INTERVAL 2 DAY));

ALTER TABLE `user` AUTO_INCREMENT = 100;
ALTER TABLE `project` AUTO_INCREMENT = 100;
ALTER TABLE `sprint` AUTO_INCREMENT = 100;
ALTER TABLE `story` AUTO_INCREMENT = 200;
ALTER TABLE `task` AUTO_INCREMENT = 500;
ALTER TABLE `scrum_event` AUTO_INCREMENT = 500;
