package com.grad.agile.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * 旧库若缺少 story.project_id 列，MyBatis 查询 backlog（按 projectId 过滤）会失败或返回空。
 * 启动时自动补列并尽量回填：已规划到 Sprint 的 story 用 sprint.project_id 回填；
 * backlog（sprint_id IS NULL）则按 demo 数据标题映射回填，避免切项目后 backlog 仍相同/为空。
 */
@Slf4j
@Component
@Order(0)
public class StoryProjectColumnMigration implements ApplicationRunner {

    private final DataSource dataSource;

    public StoryProjectColumnMigration(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void run(ApplicationArguments args) {
        try (Connection c = dataSource.getConnection()) {
            boolean hasColumn = columnExists(c, "project_id");
            if (!hasColumn) {
                try {
                    ensureColumn(c, "project_id", "BIGINT NULL");
                } catch (Exception e) {
                    log.warn("未能自动补全 story.project_id 列：{}", e.getMessage());
                    return;
                }
            }

            // 1) 先用 sprint.project_id 回填：对已规划到 Sprint 的 story
            //    这样即便 backlog 插入不带 project_id，也不会影响已规划 story 视图的口径。
            try (Statement s = c.createStatement()) {
                s.execute(
                        "UPDATE story s " +
                                "SET s.project_id = (SELECT sp.project_id FROM sprint sp WHERE sp.id = s.sprint_id) " +
                                "WHERE s.sprint_id IS NOT NULL"
                );
            }

            // 2) 再处理 backlog：sprint_id IS NULL 的 story 做标题映射回填
            //    仅覆盖 demo 里常见的标题；其它未知标题默认归到 project_id=1，保证不会为空。
            try (Statement s = c.createStatement()) {
                s.execute("UPDATE story SET project_id = 1 WHERE sprint_id IS NULL AND (project_id IS NULL OR project_id = 0)");

                // 项目 2（移动 App 会员中心）demo backlog
                s.execute("UPDATE story SET project_id = 2 WHERE sprint_id IS NULL AND title IN ('多语言文案管理','小程序码与分享','灰度发布策略')");

                // 项目 3（数据中台 BI）demo backlog
                s.execute("UPDATE story SET project_id = 3 WHERE sprint_id IS NULL AND title = '运营数据看板'");
            }

        } catch (Exception e) {
            log.warn("连接数据库失败，跳过 story 表列迁移：{}", e.getMessage());
        }
    }

    private void ensureColumn(Connection c, String column, String ddlSuffix) throws Exception {
        String sql = "ALTER TABLE `story` ADD COLUMN `" + column + "` " + ddlSuffix;
        try (Statement s = c.createStatement()) {
            s.execute(sql);
            log.info("已自动为 story 表添加列: {}", column);
        }
    }

    private boolean columnExists(Connection c, String column) throws Exception {
        String q = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS " +
                "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'story' AND COLUMN_NAME = ?";
        try (PreparedStatement ps = c.prepareStatement(q)) {
            ps.setString(1, column);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        }
        return false;
    }
}

