package com.grad.agile.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * 旧库若缺少 email/nickname 列，MyBatis 查询会失败。启动时自动补列（幂等）。
 */
@Slf4j
@Component
@Order(0)
public class UserProfileColumnMigration implements ApplicationRunner {

    private final DataSource dataSource;

    public UserProfileColumnMigration(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        try (Connection c = dataSource.getConnection()) {
            // 注意：这里必须“尽量不阻断启动”
            // 如果数据库账号没有 ALTER 权限，仍允许应用启动；后续通过报错提示你再手动补列。
            try {
                ensureColumn(c, "email", "VARCHAR(128) NULL");
            } catch (Exception e) {
                log.warn("未能自动补全 user.email 列：{}", e.getMessage());
            }
            try {
                ensureColumn(c, "nickname", "VARCHAR(64) NULL");
            } catch (Exception e) {
                log.warn("未能自动补全 user.nickname 列：{}", e.getMessage());
            }
        } catch (Exception e) {
            log.warn("连接数据库失败，跳过 user 表列迁移：{}", e.getMessage());
        }
    }

    private void ensureColumn(Connection c, String column, String ddlSuffix) throws Exception {
        if (columnExists(c, column)) {
            return;
        }
        String sql = "ALTER TABLE `user` ADD COLUMN `" + column + "` " + ddlSuffix;
        try (Statement s = c.createStatement()) {
            s.execute(sql);
            log.info("已自动为 user 表添加列: {}", column);
        }
    }

    private boolean columnExists(Connection c, String column) throws Exception {
        String q = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS "
                + "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'user' AND COLUMN_NAME = ?";
        try (PreparedStatement ps = c.prepareStatement(q)) {
            ps.setString(1, column);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }
}
