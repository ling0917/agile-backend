package com.grad.agile.config;

import com.grad.agile.interceptor.AuthInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.charset.StandardCharsets;
import java.util.List;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    private AuthInterceptor authInterceptor;

    /**
     * 配置HTTP消息转换器，解决中文乱码问题
     */
    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        // 1. 配置字符串转换器使用UTF-8编码
        StringHttpMessageConverter stringConverter = new StringHttpMessageConverter(StandardCharsets.UTF_8);
        stringConverter.setWriteAcceptCharset(false); // 避免在Content-Type中添加charset参数

        // 2. 配置JSON转换器使用UTF-8编码
        MappingJackson2HttpMessageConverter jacksonConverter = new MappingJackson2HttpMessageConverter();
        jacksonConverter.setDefaultCharset(StandardCharsets.UTF_8);

        // 3. 清空原有转换器并添加新的（确保UTF-8生效）
        converters.clear();
        converters.add(stringConverter);
        converters.add(jacksonConverter);
    }

    /**
     * 配置拦截器
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authInterceptor)
                .addPathPatterns("/**")  // 拦截所有请求
                .excludePathPatterns(
                        "/",                // 根路径（避免浏览器直接访问 401）
                        "/index.html",      // 前端入口（若有静态页）
                        "/auth/login",       // 登录接口
                        "/auth/register",    // 注册接口
                        "/auth/logout",      // 登出接口
                        "/auth/ping",        // 部署校验（无需 Token）
                        "/actuator/**",      // 健康检查等（Docker / 探活）
                        "/public/**",        // 公共接口
                        "/test/public",     // 测试公开接口（不需要 Token）
                        "/error",            // 错误页面
                        "/favicon.ico",      // 网站图标
                        "/static/**",       // 静态资源（若有）
                        "/assets/**",       // 静态资源（若有）
                        "/webjars/**"        // WebJars资源
                );
    }

    /**
     * 可选：配置跨域请求（如果需要前端调用）
     */
    // @Override
    // public void addCorsMappings(CorsRegistry registry) {
    //     registry.addMapping("/**")
    //             .allowedOriginPatterns("*")
    //             .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
    //             .allowedHeaders("*")
    //             .allowCredentials(true)
    //             .maxAge(3600);
    // }
}