// AuthController.java
package com.grad.agile.controller;

import com.grad.agile.common.Result;
import com.grad.agile.common.ResultCode;
import com.grad.agile.dto.LoginRequest;
import com.grad.agile.dto.LoginResponse;
import com.grad.agile.dto.RegisterRequest;
import com.grad.agile.dto.UpdateProfileRequest;
import com.grad.agile.dto.UserProfileResponse;
import com.grad.agile.service.AuthService;
import com.grad.agile.service.UserProfileService;
import com.grad.agile.util.TokenUtil;
import com.grad.agile.web.UserIdResolver;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
@CrossOrigin
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private TokenUtil tokenUtil;

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private UserIdResolver userIdResolver;

    /** 部署校验：无需登录；返回 ok 表示当前镜像已包含最新路由代码 */
    @GetMapping("/ping")
    public Result<Map<String, Object>> ping() {
        return Result.success(Map.of("ok", true, "api", "auth", "profileEndpoints", "/auth/me,/profile"));
    }

    /** 当前登录用户（需 JWT；由拦截器写入 auth.userId） */
    @GetMapping("/me")
    public Result<UserProfileResponse> getCurrentUser(HttpServletRequest request) {
        Long userId = userIdResolver.resolve(request);
        return userProfileService.getProfile(userId);
    }

    @PutMapping("/me")
    public Result<UserProfileResponse> updateCurrentUser(
            HttpServletRequest request,
            @RequestBody UpdateProfileRequest body) {
        Long userId = userIdResolver.resolve(request);
        return userProfileService.updateProfile(userId, body);
    }

    @PostMapping("/login")
    public Result<LoginResponse> login(@RequestBody LoginRequest request) {
        try {
            return Result.success(authService.login(request));
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "登录失败: " + e.getMessage());
        }
    }

    @PostMapping("/register")
    public Result<LoginResponse> register(@RequestBody RegisterRequest request) {
        try {
            return Result.success(authService.register(request));
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "注册失败: " + e.getMessage());
        }
    }

    @PostMapping("/logout")
    public Result<String> logout() {
        return Result.success("登出成功");
    }

    @GetMapping("/validate")
    public Result<String> validateToken(@RequestHeader(value = "Authorization", required = false) String token) {
        if (token == null || !token.startsWith("Bearer ")) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "Invalid token");
        }
        String actualToken = token.substring(7).trim();
        if (actualToken.isEmpty()) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "Invalid token");
        }
        if (!tokenUtil.validateToken(actualToken)) {
            return Result.error(ResultCode.UNAUTHORIZED.getCode(), "Invalid token");
        }
        String username = tokenUtil.getUsernameFromToken(actualToken);
        String role = tokenUtil.getRoleFromToken(actualToken);
        return Result.success("Token valid for user: " + username + ", role: " + role);
    }
}