package com.grad.agile.controller;

import com.grad.agile.common.Result;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
public class HomeController {

    @GetMapping("/")
    public Result<Map<String, Object>> home() {
        Map<String, Object> resp = new HashMap<>();
        resp.put("success", true);
        resp.put("message", "Agile 后端运行中");
        resp.put("docs", "/swagger-ui/index.html");
        resp.put("health", "/actuator/health");
        return Result.success(resp);
    }
}

