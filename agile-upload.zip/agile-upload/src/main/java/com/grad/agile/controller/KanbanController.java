package com.grad.agile.controller;

import com.grad.agile.common.Result;
import com.grad.agile.common.ResultCode;
import com.grad.agile.dto.KanbanBoardResponse;
import com.grad.agile.entity.Task;
import com.grad.agile.mapper.TaskMapper;
import com.grad.agile.security.RequireRoles;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/kanban")
@RequiredArgsConstructor
public class KanbanController {

    private final TaskMapper taskMapper;

    /**
     * 看板查询接口 - 修复状态过滤问题
     */
    @GetMapping
    public Result<Map<String, Object>> list(@RequestParam(defaultValue = "ALL") String status) {
        log.info("看板查询请求，状态参数: {}", status);

        try {
            List<Task> tasks;

            if ("ALL".equalsIgnoreCase(status)) {
                tasks = taskMapper.findAll();
                log.info("返回所有任务，数量: {}", tasks.size());
            } else {
                // 转换为大写确保与数据库匹配
                String normalizedStatus = status.toUpperCase();
                tasks = taskMapper.findByStatus(normalizedStatus);
                log.info("按状态[{}]过滤，返回任务数量: {}", normalizedStatus, tasks.size());
            }

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("status", status);
            response.put("count", tasks.size());
            response.put("tasks", tasks);

            return Result.success(response);

        } catch (Exception e) {
            log.error("看板查询异常", e);
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "查询失败: " + e.getMessage());
        }
    }

    /**
     * 拖拽更新状态接口 - 增强版
     */
    @PostMapping("/{id}/status")
    @RequireRoles({"DEVELOPER", "SCRUM_MASTER"})
    public Result<Map<String, Object>> move(
            @PathVariable Long id,
            @RequestParam String status) {

        log.info("状态更新请求，任务ID: {}, 目标状态: {}", id, status);

        try {
            // 1. 验证任务是否存在
            Task task = taskMapper.findById(id).orElse(null);
            if (task == null) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "任务不存在: id=" + id);
                response.put("taskId", id);
                log.warn("任务不存在: {}", id);
                return Result.error(ResultCode.BAD_REQUEST.getCode(), response.get("message").toString());
            }

            // 2. 验证状态有效性
            String normalizedStatus = status.toUpperCase();
            if (!isValidStatus(normalizedStatus)) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "无效的状态: " + status);
                response.put("validStatuses", new String[]{"TODO", "DOING", "DONE"});
                return Result.error(ResultCode.BAD_REQUEST.getCode(), response.get("message").toString());
            }

            // 3. 检查状态是否已改变
            if (task.getStatus().equalsIgnoreCase(normalizedStatus)) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "状态未改变，当前已是: " + normalizedStatus);
                response.put("taskId", id);
                response.put("currentStatus", task.getStatus());
                response.put("targetStatus", normalizedStatus);
                return Result.error(ResultCode.BAD_REQUEST.getCode(), response.get("message").toString());
            }

            // 4. 记录更新前的状态
            String oldStatus = task.getStatus();

            // 5. 执行状态更新
            int rows = taskMapper.updateStatus(id, normalizedStatus);

            Map<String, Object> response = new HashMap<>();
            if (rows > 0) {
                response.put("success", true);
                response.put("message", "状态更新成功");
                response.put("taskId", id);
                response.put("oldStatus", oldStatus);
                response.put("newStatus", normalizedStatus);
                response.put("affectedRows", rows);
                log.info("状态更新成功: 任务{}从[{}]变为[{}]", id, oldStatus, normalizedStatus);
            } else {
                response.put("success", false);
                response.put("message", "状态更新失败");
                response.put("taskId", id);
                log.error("状态更新失败，影响行数: {}", rows);
            }

            return Result.success(response);

        } catch (Exception e) {
            log.error("状态更新异常", e);
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "更新失败: " + e.getMessage());
        }
    }

    /**
     * 验证状态是否有效
     */
    private boolean isValidStatus(String status) {
        return "TODO".equals(status) || "DOING".equals(status) || "DONE".equals(status);
    }

    /**
     * 批量获取看板数据（三个状态列）
     */
    @GetMapping("/board")
    public Result<KanbanBoardResponse> getBoard(@RequestParam(required = false) Long sprintId) {
        try {
            KanbanBoardResponse board = new KanbanBoardResponse();
            board.setSprintId(sprintId);
            if (sprintId == null) {
                // 未传 sprintId：返回全量任务（兼容旧行为）
                board.setTodo(taskMapper.findByStatus("TODO"));
                board.setDoing(taskMapper.findByStatus("DOING"));
                board.setDone(taskMapper.findByStatus("DONE"));
            } else {
                // 传入 sprintId：严格按当前迭代过滤任务
                board.setTodo(taskMapper.findBySprintIdAndStatus(sprintId, "TODO"));
                board.setDoing(taskMapper.findBySprintIdAndStatus(sprintId, "DOING"));
                board.setDone(taskMapper.findBySprintIdAndStatus(sprintId, "DONE"));
            }
            return Result.success(board);
        } catch (Exception e) {
            log.error("获取看板数据异常", e);
            return Result.error("获取看板数据失败");
        }
    }
}