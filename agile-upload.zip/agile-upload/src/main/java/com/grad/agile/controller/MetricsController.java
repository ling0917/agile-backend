package com.grad.agile.controller;

import com.grad.agile.common.Result;
import com.grad.agile.common.ResultCode;
import com.grad.agile.security.RequireRoles;
import com.grad.agile.service.MetricsService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/metrics")
@RequiredArgsConstructor
public class MetricsController {
    private final MetricsService metricsService;

    @GetMapping("/sprints/{sprintId}")
    @RequireRoles({"SCRUM_MASTER", "PRODUCT_OWNER"})
    public Result<Map<String, Object>> sprintMetrics(@PathVariable Long sprintId) {
        try {
            return Result.success(metricsService.getSprintMetrics(sprintId));
        } catch (Exception e) {
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "获取度量失败: " + e.getMessage());
        }
    }
}

