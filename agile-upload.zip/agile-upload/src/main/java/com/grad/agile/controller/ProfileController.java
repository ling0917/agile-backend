package com.grad.agile.controller;

import com.grad.agile.common.Result;
import com.grad.agile.dto.UpdateProfileRequest;
import com.grad.agile.dto.UserProfileResponse;
import com.grad.agile.service.UserProfileService;
import com.grad.agile.web.UserIdResolver;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 个人信息（与 /auth/me 等价，便于排查路由与代理问题）。
 */
@RestController
@RequestMapping("/profile")
@RequiredArgsConstructor
public class ProfileController {

    private final UserProfileService userProfileService;
    private final UserIdResolver userIdResolver;

    @GetMapping
    public Result<UserProfileResponse> get(HttpServletRequest request) {
        Long userId = userIdResolver.resolve(request);
        return userProfileService.getProfile(userId);
    }

    @PutMapping
    public Result<UserProfileResponse> put(HttpServletRequest request, @RequestBody UpdateProfileRequest body) {
        Long userId = userIdResolver.resolve(request);
        return userProfileService.updateProfile(userId, body);
    }
}
