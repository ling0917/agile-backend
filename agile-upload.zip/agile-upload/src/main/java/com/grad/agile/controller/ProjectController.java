package com.grad.agile.controller;

import com.grad.agile.common.Result;
import com.grad.agile.common.ResultCode;
import com.grad.agile.entity.Project;
import com.grad.agile.mapper.ProjectMapper;
import com.grad.agile.security.RequireRoles;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/projects")
@RequiredArgsConstructor
public class ProjectController {

    private final ProjectMapper projectMapper;

    @GetMapping
    public Result<List<Project>> list() {
        return Result.success(projectMapper.findAll());
    }

    @GetMapping("/{id}")
    public Result<Project> getById(@PathVariable Long id) {
        try {
            Project project = projectMapper.findById(id);
            if (project == null) {
                return Result.error(ResultCode.NOT_FOUND.getCode(), "项目不存在");
            }
            return Result.success(project);
        } catch (Exception e) {
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "获取项目失败: " + e.getMessage());
        }
    }

    @PostMapping
    @RequireRoles({"PRODUCT_OWNER"})
    public Result<Integer> create(@RequestBody Project project) {
        try {
            return Result.success(projectMapper.insert(project));
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "创建项目失败: " + e.getMessage());
        }
    }

    @PutMapping("/{id}")
    @RequireRoles({"PRODUCT_OWNER"})
    public Result<Integer> update(@PathVariable Long id, @RequestBody Project project) {
        try {
            project.setId(id);
            return Result.success(projectMapper.update(project));
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "更新项目失败: " + e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    @RequireRoles({"PRODUCT_OWNER"})
    public Result<Integer> delete(@PathVariable Long id) {
        try {
            return Result.success(projectMapper.delete(id));
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "删除项目失败: " + e.getMessage());
        }
    }
}
