package com.grad.agile.controller;

import com.grad.agile.common.Result;
import com.grad.agile.common.ResultCode;
import com.grad.agile.entity.ScrumEvent;
import com.grad.agile.mapper.ScrumEventMapper;
import com.grad.agile.security.RequireRoles;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/scrum")
@RequiredArgsConstructor
public class ScrumEventController {
    private final ScrumEventMapper scrumEventMapper;

    /**
     * 每日站会记录（开发人员/SM 均可提交）
     */
    @PostMapping("/standup")
    @RequireRoles({"DEVELOPER", "SCRUM_MASTER"})
    public Result<ScrumEvent> createStandup(@RequestBody ScrumEvent event) {
        try {
            event.setType("STANDUP");
            if (event.getCreatedAt() == null) {
                event.setCreatedAt(LocalDateTime.now());
            }
            scrumEventMapper.insert(event);
            return Result.success(event);
        } catch (Exception e) {
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "提交站会失败: " + e.getMessage());
        }
    }

    /**
     * 评审记录（PO/SM）
     */
    @PostMapping("/review")
    @RequireRoles({"PRODUCT_OWNER", "SCRUM_MASTER"})
    public Result<ScrumEvent> createReview(@RequestBody ScrumEvent event) {
        try {
            event.setType("REVIEW");
            if (event.getCreatedAt() == null) {
                event.setCreatedAt(LocalDateTime.now());
            }
            scrumEventMapper.insert(event);
            return Result.success(event);
        } catch (Exception e) {
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "提交评审失败: " + e.getMessage());
        }
    }

    /**
     * 回顾记录（SM）
     */
    @PostMapping("/retro")
    @RequireRoles({"SCRUM_MASTER"})
    public Result<ScrumEvent> createRetro(@RequestBody ScrumEvent event) {
        try {
            event.setType("RETRO");
            if (event.getCreatedAt() == null) {
                event.setCreatedAt(LocalDateTime.now());
            }
            scrumEventMapper.insert(event);
            return Result.success(event);
        } catch (Exception e) {
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "提交回顾失败: " + e.getMessage());
        }
    }

    @GetMapping("/sprint/{sprintId}")
    public Result<List<ScrumEvent>> listBySprint(@PathVariable Long sprintId) {
        try {
            return Result.success(scrumEventMapper.findBySprint(sprintId));
        } catch (Exception e) {
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "获取站会失败: " + e.getMessage());
        }
    }

    @GetMapping("/sprint/{sprintId}/{type}")
    public Result<List<ScrumEvent>> listBySprintAndType(
            @PathVariable Long sprintId,
            @PathVariable String type) {
        try {
            return Result.success(scrumEventMapper.findBySprintAndType(sprintId, type.toUpperCase()));
        } catch (Exception e) {
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "获取站会失败: " + e.getMessage());
        }
    }
}

