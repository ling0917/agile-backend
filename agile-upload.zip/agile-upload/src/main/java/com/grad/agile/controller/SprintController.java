// controller/SprintController.java
package com.grad.agile.controller;

import com.grad.agile.common.Result;
import com.grad.agile.common.ResultCode;
import com.grad.agile.entity.Sprint;
import com.grad.agile.dto.BurndownData;
import com.grad.agile.security.RequireRoles;
import com.grad.agile.service.SprintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/sprints")
public class SprintController {

    @Autowired
    private SprintService sprintService;

    @GetMapping
    public Result<List<Sprint>> getAllSprints() {
        try {
            List<Sprint> sprints = sprintService.getAllSprints();
            return Result.success(sprints);
        } catch (Exception e) {
            return Result.error("获取迭代列表失败: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public Result<Sprint> getSprintById(@PathVariable Long id) {
        try {
            Sprint sprint = sprintService.getSprintById(id);
            if (sprint == null) {
                return Result.error(ResultCode.NOT_FOUND.getCode(), "迭代不存在");
            }
            return Result.success(sprint);
        } catch (Exception e) {
            return Result.error("获取迭代失败: " + e.getMessage());
        }
    }

    @GetMapping("/{id}/burndown")
    public Result<BurndownData> getBurndownData(@PathVariable Long id) {
        try {
            BurndownData burndownData = sprintService.getBurndownData(id);
            if (burndownData == null) {
                return Result.error(ResultCode.NOT_FOUND.getCode(), "燃尽图数据不存在");
            }
            return Result.success(burndownData);
        } catch (Exception e) {
            return Result.error("获取燃尽图失败: " + e.getMessage());
        }
    }

    @PostMapping
    @RequireRoles({"SCRUM_MASTER"})
    public Result<Sprint> createSprint(@RequestBody Sprint sprint) {
        try {
            Sprint createdSprint = sprintService.createSprint(sprint);
            return Result.success(createdSprint);
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "创建迭代失败: " + e.getMessage());
        }
    }

    @PutMapping("/{id}")
    @RequireRoles({"SCRUM_MASTER"})
    public Result<Sprint> updateSprint(
            @PathVariable Long id,
            @RequestBody Sprint sprint) {
        try {
            Sprint updatedSprint = sprintService.updateSprint(id, sprint);
            return Result.success(updatedSprint);
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "更新迭代失败: " + e.getMessage());
        }
    }

    @PutMapping("/{id}/start")
    @RequireRoles({"SCRUM_MASTER"})
    public Result<Sprint> startSprint(@PathVariable Long id) {
        try {
            Sprint sprint = sprintService.startSprint(id);
            return Result.success(sprint);
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "启动迭代失败: " + e.getMessage());
        }
    }

    @PutMapping("/{id}/complete")
    @RequireRoles({"SCRUM_MASTER"})
    public Result<Sprint> completeSprint(@PathVariable Long id) {
        try {
            Sprint sprint = sprintService.completeSprint(id);
            return Result.success(sprint);
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "完成迭代失败: " + e.getMessage());
        }
    }

    @GetMapping("/active")
    public Result<List<Sprint>> getActiveSprints() {
        try {
            return Result.success(sprintService.getActiveSprints());
        } catch (Exception e) {
            return Result.error("获取活跃迭代失败: " + e.getMessage());
        }
    }

    @GetMapping("/completed")
    public Result<List<Sprint>> getCompletedSprints() {
        try {
            return Result.success(sprintService.getCompletedSprints());
        } catch (Exception e) {
            return Result.error("获取已完成迭代失败: " + e.getMessage());
        }
    }

    @GetMapping("/project/{projectId}")
    public Result<List<Sprint>> getSprintsByProjectId(@PathVariable Long projectId) {
        try {
            return Result.success(sprintService.getSprintsByProjectId(projectId));
        } catch (Exception e) {
            return Result.error("获取项目迭代失败: " + e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    @RequireRoles({"SCRUM_MASTER"})
    public Result<String> deleteSprint(@PathVariable Long id) {
        try {
            sprintService.deleteSprint(id);
            return Result.success("迭代删除成功");
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "删除迭代失败: " + e.getMessage());
        }
    }
    // controller/SprintController.java - 添加统计方法
    @GetMapping("/{id}/statistics")
    @RequireRoles({"SCRUM_MASTER", "PRODUCT_OWNER"})
    public Result<Map<String, Object>> getSprintStatistics(@PathVariable Long id) {
        try {
            Map<String, Object> statistics = sprintService.getSprintStatistics(id);
            return Result.success(statistics);
        } catch (Exception e) {
            return Result.error("获取统计信息失败: " + e.getMessage());
        }
    }
}