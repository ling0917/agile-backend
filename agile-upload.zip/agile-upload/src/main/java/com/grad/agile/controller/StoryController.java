package com.grad.agile.controller;

import com.grad.agile.common.Result;
import com.grad.agile.entity.Story;
import com.grad.agile.entity.Task;
import com.grad.agile.mapper.StoryMapper;
import com.grad.agile.mapper.TaskMapper;
import com.grad.agile.security.RequireRoles;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/stories")
@RequiredArgsConstructor
public class StoryController {

    private final StoryMapper storyMapper;
    private final TaskMapper taskMapper;

    @GetMapping
    public Result<List<Story>> list() {
        return Result.success(storyMapper.findAll());
    }

    /**
     * 产品 Backlog（未规划进 Sprint 的 Story）
     */
    @GetMapping("/backlog")
    public Result<List<Story>> backlog(@RequestParam Long projectId) {
        return Result.success(storyMapper.findBacklogByProjectId(projectId));
    }

    @GetMapping("/sprint/{sprintId}")
    public Result<List<Story>> bySprint(@PathVariable Long sprintId) {
        return Result.success(storyMapper.findBySprintId(sprintId));
    }

    @PostMapping
    @RequireRoles({"PRODUCT_OWNER"})
    public Result<Story> create(@RequestBody Story story) {
        if (story.getStatus() == null || story.getStatus().trim().isEmpty()) {
            story.setStatus("TODO");
        }
        if (story.getPriority() == null || story.getPriority().trim().isEmpty()) {
            story.setPriority("MEDIUM");
        }
        if (story.getCreateTime() == null) {
            story.setCreateTime(LocalDateTime.now());
        }
        if (story.getProjectId() == null) {
            // 为兼容旧前端/旧数据：未传 project_id 时默认归到项目 1
            story.setProjectId(1L);
        }
        storyMapper.insert(story);
        return Result.success(story);
    }

    @PutMapping("/{id}")
    @RequireRoles({"PRODUCT_OWNER"})
    public Result<Story> update(@PathVariable Long id, @RequestBody Story story) {
        story.setId(id);
        storyMapper.update(story);
        return Result.success(storyMapper.findById(id).orElseThrow(() -> new RuntimeException("Story 不存在: id=" + id)));
    }

    /**
     * 迭代规划：把 Story 规划到指定 Sprint
     */
    @PostMapping("/{id}/plan")
    @RequireRoles({"PRODUCT_OWNER", "SCRUM_MASTER"})
    public Result<String> planToSprint(@PathVariable Long id, @RequestParam Long sprintId) {
        int rows = storyMapper.planToSprint(id, sprintId);
        if (rows <= 0) return Result.error("规划失败");

        // 规划 Story 后，自动生成 1 条 TODO 占位任务到该 Sprint（用于任务看板联动）
        Story story = storyMapper.findById(id).orElse(null);
        if (story == null) return Result.error("规划失败");

        Integer existingTasks = taskMapper.countByStoryId(id);
        if (existingTasks == null || existingTasks == 0) {
            Task task = new Task();
            // 占位任务标题直接使用 Story 标题，避免 UI 出现冗余前缀
            task.setTitle(story.getTitle());
            task.setDescription(story.getDescription());
            task.setPriority(story.getPriority() != null ? story.getPriority() : "MEDIUM");
            task.setStatus("TODO");
            task.setAssigneeId(null);
            task.setStoryPoints(story.getStoryPoint() != null ? story.getStoryPoint() : 0);
            task.setSprintId(sprintId != null ? sprintId.intValue() : null);
            task.setStoryId(id.intValue());
            task.setCreatedAt(LocalDateTime.now());
            task.setUpdatedAt(LocalDateTime.now());
            taskMapper.insert(task);
        } else {
            // 如果已有任务（可能手动拆分），则把任务重新绑定到当前 sprint
            taskMapper.updateSprintIdByStoryId(sprintId, id);
            // 同时清理旧版本占位任务的标题前缀（不影响手动拆分的任务标题）
            taskMapper.normalizePlaceholderTitle(id, story.getTitle());
        }

        return Result.success("规划成功");
    }

    /**
     * 移回 Backlog：取消 Sprint 归属
     */
    @PostMapping("/{id}/unplan")
    @RequireRoles({"PRODUCT_OWNER", "SCRUM_MASTER"})
    public Result<String> moveToBacklog(@PathVariable Long id) {
        int rows = storyMapper.moveToBacklog(id);
        if (rows <= 0) return Result.error("操作失败");

        // 取消规划时：把该 Story 下任务从 sprint 中移除（避免看板仍显示）
        taskMapper.clearSprintIdByStoryId(id);
        return Result.success("已移回 Backlog");
    }

    @DeleteMapping("/{id}")
    @RequireRoles({"PRODUCT_OWNER"})
    public Result<String> delete(@PathVariable Long id) {
        int rows = storyMapper.deleteById(id);
        return rows > 0 ? Result.success("删除成功") : Result.error("删除失败");
    }
}