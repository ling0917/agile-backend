package com.grad.agile.controller;

import com.grad.agile.common.Result;
import com.grad.agile.common.ResultCode;
import com.grad.agile.dto.TaskRequest;
import com.grad.agile.entity.Task;
import com.grad.agile.security.RequireRoles;
import com.grad.agile.service.TaskService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/tasks")
@RequiredArgsConstructor
public class TaskController {
    private final TaskService taskService;

    // 创建任务
    @PostMapping
    @RequireRoles({"DEVELOPER", "SCRUM_MASTER"})
    public Result<Task> createTask(@RequestBody TaskRequest request) {
        // 手动验证请求参数
        String validationError = request.validate();
        if (validationError != null) {
            log.warn("任务创建参数验证失败: {}", validationError);
            return Result.error(ResultCode.BAD_REQUEST.getCode(), validationError);
        }

        // 设置默认值
        if (request.getStatus() == null) {
            request.setStatus(TaskRequest.Status.TODO);
        }

        if (request.getPriority() == null) {
            request.setPriority(TaskRequest.Priority.MEDIUM);
        }

        if (request.getStoryPoints() == null) {
            request.setStoryPoints(1);
        }

        try {
            Task task = taskService.createTask(request);
            log.info("任务创建成功: ID={}, Title={}", task.getId(), task.getTitle());
            return Result.success(task);
        } catch (Exception e) {
            log.error("任务创建失败", e);
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "任务创建失败: " + e.getMessage());
        }
    }

    // 查询所有任务
    @GetMapping
    public Result<List<Task>> getAllTasks() {
        try {
            List<Task> tasks = taskService.getAllTasks();
            log.info("查询所有任务成功，共 {} 条", tasks.size());
            return Result.success(tasks);
        } catch (Exception e) {
            log.error("查询所有任务失败", e);
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "查询任务失败");
        }
    }

    // 查询单个任务
    @GetMapping("/{id}")
    public Result<Task> getTaskById(@PathVariable Long id) {
        try {
            Task task = taskService.getTaskById(id);
            if (task == null) {
                log.warn("任务不存在: ID={}", id);
                return Result.error(ResultCode.NOT_FOUND.getCode(), "任务不存在");
            }
            log.info("查询任务成功: ID={}", id);
            return Result.success(task);
        } catch (Exception e) {
            log.error("查询任务失败: ID={}", id, e);
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "查询任务失败");
        }
    }

    // 更新任务
    @PutMapping("/{id}")
    @RequireRoles({"DEVELOPER", "SCRUM_MASTER"})
    public Result<Task> updateTask(@PathVariable Long id, @RequestBody TaskRequest request) {
        // 手动验证请求参数
        String validationError = request.validate();
        if (validationError != null) {
            log.warn("任务更新参数验证失败: ID={}, Error={}", id, validationError);
            return Result.error(ResultCode.BAD_REQUEST.getCode(), validationError);
        }

        try {
            Task task = taskService.updateTask(id, request);
            if (task == null) {
                log.warn("任务更新失败，任务不存在: ID={}", id);
                return Result.error(ResultCode.NOT_FOUND.getCode(), "任务不存在");
            }
            log.info("任务更新成功: ID={}", id);
            return Result.success(task);
        } catch (Exception e) {
            log.error("任务更新失败: ID={}", id, e);
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "任务更新失败");
        }
    }

    // 删除任务
    @DeleteMapping("/{id}")
    @RequireRoles({"SCRUM_MASTER"})
    public Result<Void> deleteTask(@PathVariable Long id) {
        try {
            boolean deleted = taskService.deleteTask(id);
            if (!deleted) {
                log.warn("任务删除失败，任务不存在: ID={}", id);
                return Result.error(ResultCode.NOT_FOUND.getCode(), "任务不存在");
            }
            log.info("任务删除成功: ID={}", id);
            return Result.success();
        } catch (Exception e) {
            log.error("任务删除失败: ID={}", id, e);
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "任务删除失败");
        }
    }

    // 根据状态查询任务
    @GetMapping("/status/{status}")
    public Result<List<Task>> getTasksByStatus(@PathVariable String status) {
        // 验证状态参数
        if (!TaskRequest.Status.isValid(status)) {
            log.warn("状态参数无效: {}", status);
            return Result.error(ResultCode.BAD_REQUEST.getCode(),
                    "状态参数无效，必须是 TODO、DOING 或 DONE");
        }

        try {
            List<Task> tasks = taskService.getTasksByStatus(status);
            log.info("按状态查询任务成功: Status={}, Count={}", status, tasks.size());
            return Result.success(tasks);
        } catch (Exception e) {
            log.error("按状态查询任务失败: Status={}", status, e);
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "查询任务失败");
        }
    }

    // 新增：根据迭代ID查询任务
    @GetMapping("/sprint/{sprintId}")
    public Result<List<Task>> getTasksBySprint(@PathVariable Long sprintId) {
        try {
            List<Task> tasks = taskService.getTasksBySprint(sprintId);
            log.info("按迭代查询任务成功: SprintID={}, Count={}", sprintId, tasks.size());
            return Result.success(tasks);
        } catch (Exception e) {
            log.error("按迭代查询任务失败: SprintID={}", sprintId, e);
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "查询任务失败");
        }
    }
}