package com.grad.agile.controller;

import com.grad.agile.common.Result;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test")
public class TestController {

    @GetMapping("/public")
    public Result<String> publicEndpoint() {
        return Result.success("✅ 这是一个公开接口，不需要Token");
    }

    @GetMapping("/protected")
    public Result<String> protectedEndpoint() {
        return Result.success("🔒 这是一个受保护接口，需要Token才能访问");
    }

    @GetMapping("/admin-only")
    public Result<String> adminOnlyEndpoint() {
        return Result.success("👑 这是管理员专属接口");
    }
}