package com.grad.agile.controller;

import com.grad.agile.common.Result;
import com.grad.agile.common.ResultCode;
import com.grad.agile.entity.User;
import com.grad.agile.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {

    private final UserMapper userMapper;

    @GetMapping
    public Result<List<User>> list() {
        try {
            return Result.success(userMapper.findAll());
        } catch (Exception e) {
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "获取用户列表失败: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public Result<User> one(@PathVariable Long id) {
        try {
            User u = userMapper.findById(id);
            if (u == null) {
                return Result.error(ResultCode.NOT_FOUND.getCode(), "用户不存在");
            }
            return Result.success(u);
        } catch (Exception e) {
            return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "获取用户失败: " + e.getMessage());
        }
    }

    // 其他方法也需要添加...
    @PostMapping
    public Result<Integer> add(@RequestBody User user) {
        try {
            return Result.success(userMapper.insert(user));
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "创建用户失败: " + e.getMessage());
        }
    }

    @PutMapping
    public Result<Integer> update(@RequestBody User user) {
        try {
            return Result.success(userMapper.update(user));
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "更新用户失败: " + e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public Result<Integer> delete(@PathVariable Long id) {
        try {
            return Result.success(userMapper.deleteById(id));
        } catch (Exception e) {
            return Result.error(ResultCode.BAD_REQUEST.getCode(), "删除用户失败: " + e.getMessage());
        }
    }
}