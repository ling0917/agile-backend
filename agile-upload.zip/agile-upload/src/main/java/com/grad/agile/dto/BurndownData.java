package com.grad.agile.dto;

import lombok.Data;
import java.time.LocalDate;
import java.util.List;

@Data
public class BurndownData {
    private Long sprintId;
    private String sprintName;
    private List<LocalDate> dates;                    // 日期数组
    private List<Integer> actualRemainingPoints;      // 实际剩余点数数组
    private List<Integer> idealRemainingPoints;       // 理想剩余点数数组
    private Integer totalPoints;                      // 总故事点数
    private Integer completedPoints;                  // 已完成故事点数
    private Double completionRate;                    // 完成率
}