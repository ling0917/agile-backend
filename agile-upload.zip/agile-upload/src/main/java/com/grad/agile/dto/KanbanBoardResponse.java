package com.grad.agile.dto;

import com.grad.agile.entity.Task;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class KanbanBoardResponse {
    private Long sprintId;
    private List<Task> todo;
    private List<Task> doing;
    private List<Task> done;
}

