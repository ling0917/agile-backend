// src/main/java/com/grad/agile/dto/LoginRequest.java
package com.grad.agile.dto;

import lombok.Data;

@Data
public class LoginRequest {
    private String username;
    private String password;
}