// src/main/java/com/grad/agile/dto/LoginResponse.java
package com.grad.agile.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LoginResponse {
    private String token;
    private String username;
    private String role;
    private String email;
    private String message;
}