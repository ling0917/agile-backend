package com.grad.agile.dto;

import lombok.Data;

@Data
public class RegisterRequest {
    private String username;
    private String password;
    private String email;
    /** 可选，默认与用户名相同 */
    private String nickname;
    /**
     * PRODUCT_OWNER / SCRUM_MASTER / DEVELOPER
     */
    private String role;
}

