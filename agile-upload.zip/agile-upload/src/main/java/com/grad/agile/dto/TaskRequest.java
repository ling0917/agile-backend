package com.grad.agile.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class TaskRequest {
    private String title;
    private String description;
    private String priority;      // HIGH, MEDIUM, LOW
    private String status;        // TODO, DOING, DONE
    private Integer assigneeId;
    private Integer storyPoints;
    private Integer sprintId;
    private Integer storyId;

    // 枚举常量定义
    public static class Priority {
        public static final String HIGH = "HIGH";
        public static final String MEDIUM = "MEDIUM";
        public static final String LOW = "LOW";

        public static boolean isValid(String priority) {
            return HIGH.equals(priority) || MEDIUM.equals(priority) || LOW.equals(priority);
        }
    }

    public static class Status {
        public static final String TODO = "TODO";
        public static final String DOING = "DOING";
        public static final String DONE = "DONE";

        public static boolean isValid(String status) {
            return TODO.equals(status) || DOING.equals(status) || DONE.equals(status);
        }
    }

    // 构造方法
    public TaskRequest() {}

    public TaskRequest(String title, String description, String priority,
                       String status, Integer assigneeId, Integer storyPoints,
                       Integer sprintId, Integer storyId) {
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = status;
        this.assigneeId = assigneeId;
        this.storyPoints = storyPoints;
        this.sprintId = sprintId;
        this.storyId = storyId;
    }

    /**
     * 验证请求参数
     * @return 错误信息，如果返回 null 表示验证通过
     */
    public String validate() {
        if (title == null || title.trim().isEmpty()) {
            return "任务标题不能为空";
        }

        if (priority != null && !Priority.isValid(priority)) {
            return "优先级必须是 HIGH、MEDIUM 或 LOW";
        }

        if (status != null && !Status.isValid(status)) {
            return "状态必须是 TODO、DOING 或 DONE";
        }

        if (storyPoints != null && storyPoints < 0) {
            return "故事点数不能为负数";
        }

        if (sprintId != null && sprintId <= 0) {
            return "迭代ID必须大于0";
        }

        if (assigneeId != null && assigneeId <= 0) {
            return "指派人ID必须大于0";
        }

        return null; // 验证通过
    }

    /**
     * 获取默认状态（如果未设置）
     */
    public String getStatusOrDefault() {
        return status != null ? status : Status.TODO;
    }

    /**
     * 获取默认优先级（如果未设置）
     */
    public String getPriorityOrDefault() {
        return priority != null ? priority : Priority.MEDIUM;
    }

    /**
     * 获取默认故事点数（如果未设置）
     */
    public int getStoryPointsOrDefault() {
        return storyPoints != null ? storyPoints : 1;
    }
}