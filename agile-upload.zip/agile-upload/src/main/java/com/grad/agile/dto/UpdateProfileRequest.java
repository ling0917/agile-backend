package com.grad.agile.dto;

import lombok.Data;

@Data
public class UpdateProfileRequest {
    /** 展示昵称，可为空 */
    private String nickname;
    private String email;
    /** 新密码（非空则修改密码） */
    private String newPassword;
    /** 修改密码时必须提供当前密码 */
    private String currentPassword;
}
