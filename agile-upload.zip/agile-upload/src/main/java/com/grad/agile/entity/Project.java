// src/main/java/com/grad/agile/project/Project.java
package com.grad.agile.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Project {
    private Long id;
    private String name;
    private String description;
    private Long ownerId;  // 项目负责人（用户ID）
    private LocalDateTime createdAt;
}