package com.grad.agile.entity;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ScrumEvent {
    private Long id;
    private Long sprintId;
    private Long userId;
    /**
     * STANDUP / REVIEW / RETRO
     */
    private String type;
    private String content;
    private String blockers;
    private LocalDateTime createdAt;
}

