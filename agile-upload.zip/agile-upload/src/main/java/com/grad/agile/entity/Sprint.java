package com.grad.agile.entity;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data // Lombok 自动生成 getter/setter/toString 等
public class Sprint {
    private Long id;
    private String name;
    private String description;
    private String goal;           // 新增：迭代目标（对应 getGoal()）
    private LocalDate startDate;   // 迭代开始日期
    private LocalDate endDate;     // 迭代结束日期
    private String status;         // PLANNING, ACTIVE, COMPLETED
    private Long projectId;
    private Integer capacity;      // 新增：迭代容量（对应 getCapacity()）
    private Integer totalStoryPoints;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // 计算迭代天数
    public int getDays() {
        if (startDate == null || endDate == null) {
            return 0;
        }
        return (int) java.time.temporal.ChronoUnit.DAYS.between(startDate, endDate) + 1;
    }

    // 如果不用 Lombok，需手动写 getter/setter（示例）：
    // public String getGoal() { return goal; }
    // public void setGoal(String goal) { this.goal = goal; }
    // public Integer getCapacity() { return capacity; }
    // public void setCapacity(Integer capacity) { this.capacity = capacity; }
}