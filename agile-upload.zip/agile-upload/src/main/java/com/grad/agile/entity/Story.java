package com.grad.agile.entity;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Story {
    private Long id;
    /** 所属项目（用于区分不同项目的 Backlog） */
    private Long projectId;
    private Long sprintId;
    private String title;
    private Integer storyPoint;
    private String status;
    private String description;
    private String priority; // HIGH / MEDIUM / LOW
    private LocalDateTime createTime;
}