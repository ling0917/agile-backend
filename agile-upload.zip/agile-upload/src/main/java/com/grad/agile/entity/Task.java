package com.grad.agile.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Task {
    private Long id;
    private String title;
    private String description;
    private String priority;      // HIGH, MEDIUM, LOW
    private String status;        // TODO, DOING, DONE
    private Integer assigneeId;
    private Integer storyPoints;
    private Integer sprintId;
    private Integer storyId;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}