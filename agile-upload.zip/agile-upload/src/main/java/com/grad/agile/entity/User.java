package com.grad.agile.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class User {
    private Long id;
    private String username;
    private String password;
    private String email;
    /** 展示用昵称，可与登录名不同 */
    private String nickname;
    private String role;// PRODUCT_OWNER, SCRUM_MASTER, DEVELOPER
    private LocalDateTime createTime;
    private Boolean enabled;
}