package com.grad.agile.handler;

import com.grad.agile.common.Result;
import com.grad.agile.common.ResultCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    // 处理验证异常
    @ExceptionHandler({BindException.class, MethodArgumentNotValidException.class})
    public Result<?> handleValidationException(Exception e) {
        log.error("参数验证异常: ", e);
        return Result.error(ResultCode.BAD_REQUEST.getCode(), "请求参数验证失败");
    }

    // 处理业务异常
    @ExceptionHandler(RuntimeException.class)
    public Result<?> handleRuntimeException(RuntimeException e) {
        log.error("业务运行时异常: ", e);
        return Result.error(ResultCode.BAD_REQUEST.getCode(), e.getMessage());
    }

    // 无匹配接口时返回真实 404，便于前端与网关识别（避免 HTTP 200 + code=404）
    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<Result<?>> handleNoResourceFound(NoResourceFoundException e) {
        Result<?> body = Result.error(ResultCode.NOT_FOUND.getCode(), "资源不存在: " + e.getResourcePath());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }

    // 处理其他异常
    @ExceptionHandler(Exception.class)
    public Result<?> handleException(Exception e) {
        log.error("系统异常: ", e);
        return Result.error(ResultCode.INTERNAL_SERVER_ERROR.getCode(), "系统异常，请联系管理员");
    }
}