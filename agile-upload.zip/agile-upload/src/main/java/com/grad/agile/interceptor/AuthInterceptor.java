package com.grad.agile.interceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.grad.agile.security.RequireRoles;
import com.grad.agile.util.TokenUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.method.HandlerMethod;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class AuthInterceptor implements HandlerInterceptor {

    private final TokenUtil tokenUtil;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler) throws Exception {

        String path = request.getRequestURI();

        // 0. 预检请求直接放行（CORS）
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        // 1. 公开接口由 WebConfig.excludePathPatterns 配置；此处不再整段放行 /auth/，
        //    否则 /auth/me 等需登录的接口会跳过鉴权且不写入 auth.userId。

        // 2. 读取并校验 Bearer Token
        String auth = request.getHeader("Authorization");
        if (auth == null || !auth.startsWith("Bearer ")) {
            writeUnauthorized(response, "缺少或非法的 Authorization Header");
            return false;
        }

        String token = auth.substring(7).trim();
        if (token.isEmpty() || !tokenUtil.validateToken(token)) {
            writeUnauthorized(response, "Token 无效或已过期");
            return false;
        }

        // 3. 把解析后的身份信息放到 request，供后续权限控制/业务使用
        String username = tokenUtil.getUsernameFromToken(token);
        String role = tokenUtil.getRoleFromToken(token);
        Long userId = tokenUtil.getUserIdFromToken(token);

        request.setAttribute("auth.username", username);
        request.setAttribute("auth.role", role);
        request.setAttribute("auth.userId", userId);

        // 4. 方法级角色校验（可选）
        if (handler instanceof HandlerMethod hm) {
            RequireRoles requireRoles = hm.getMethodAnnotation(RequireRoles.class);
            if (requireRoles == null) {
                requireRoles = hm.getBeanType().getAnnotation(RequireRoles.class);
            }
            if (requireRoles != null) {
                if (role == null || Arrays.stream(requireRoles.value()).noneMatch(r -> r.equalsIgnoreCase(role))) {
                    writeForbidden(response, "权限不足");
                    return false;
                }
            }
        }

        return true;
    }

    private void writeUnauthorized(HttpServletResponse response, String message) throws Exception {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> body = new HashMap<>();
        body.put("success", false);
        body.put("code", 401);
        body.put("message", message);
        response.getWriter().write(objectMapper.writeValueAsString(body));
    }

    private void writeForbidden(HttpServletResponse response, String message) throws Exception {
        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> body = new HashMap<>();
        body.put("success", false);
        body.put("code", 403);
        body.put("message", message);
        response.getWriter().write(objectMapper.writeValueAsString(body));
    }
}