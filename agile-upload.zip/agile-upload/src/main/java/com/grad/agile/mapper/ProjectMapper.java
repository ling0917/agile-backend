package com.grad.agile.mapper;

import com.grad.agile.entity.Project;
import org.apache.ibatis.annotations.*;
import java.util.List;

@Mapper
public interface ProjectMapper {

    @Select("SELECT * FROM project")
    List<Project> findAll();

    @Select("SELECT * FROM project WHERE id = #{id}")
    Project findById(Long id);

    @Select("SELECT * FROM project WHERE owner_id = #{ownerId}")
    List<Project> findByOwnerId(Long ownerId);

    @Insert("INSERT INTO project(name, description, owner_id) VALUES(#{name}, #{description}, #{ownerId})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Project project);

    @Update("UPDATE project SET name = #{name}, description = #{description}, owner_id = #{ownerId} WHERE id = #{id}")
    int update(Project project);

    @Delete("DELETE FROM project WHERE id = #{id}")
    int delete(Long id);
}