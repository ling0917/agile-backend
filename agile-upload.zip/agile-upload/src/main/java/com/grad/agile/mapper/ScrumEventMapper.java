package com.grad.agile.mapper;

import com.grad.agile.entity.ScrumEvent;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ScrumEventMapper {

    @Insert("INSERT INTO scrum_event (sprint_id, user_id, type, content, blockers, created_at) " +
            "VALUES (#{sprintId}, #{userId}, #{type}, #{content}, #{blockers}, #{createdAt})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(ScrumEvent event);

    @Select("SELECT * FROM scrum_event WHERE sprint_id = #{sprintId} AND type = #{type} ORDER BY created_at DESC")
    List<ScrumEvent> findBySprintAndType(@Param("sprintId") Long sprintId, @Param("type") String type);

    @Select("SELECT * FROM scrum_event WHERE sprint_id = #{sprintId} ORDER BY created_at DESC")
    List<ScrumEvent> findBySprint(@Param("sprintId") Long sprintId);
}

