package com.grad.agile.mapper;

import com.grad.agile.entity.Sprint;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
@Mapper
public interface SprintMapper {

    @Select("SELECT * FROM sprint")
    List<Sprint> findAll();

    @Select("SELECT * FROM sprint WHERE id = #{id}")
    Optional<Sprint> findById(Long id);

    @Insert("INSERT INTO sprint (name, description, start_date, end_date, status, project_id, total_story_points, created_at, updated_at) " +
            "VALUES (#{name}, #{description}, #{startDate}, #{endDate}, #{status}, #{projectId}, #{totalStoryPoints}, #{createdAt}, #{updatedAt})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(Sprint sprint);

    @Update("UPDATE sprint SET " +
            "name = #{name}, " +
            "description = #{description}, " +
            "start_date = #{startDate}, " +
            "end_date = #{endDate}, " +
            "status = #{status}, " +
            "project_id = #{projectId}, " +
            "total_story_points = #{totalStoryPoints}, " +
            "updated_at = #{updatedAt} " +
            "WHERE id = #{id}")
    void update(Sprint sprint);

    @Delete("DELETE FROM sprint WHERE id = #{id}")
    void deleteById(Long id);

    // 新增：根据状态查询迭代（解决 findByStatus 报错）
    @Select("SELECT * FROM sprint WHERE status = #{status}")
    List<Sprint> findByStatus(String status);

    // 原有方法保留
    @Select("SELECT * FROM sprint WHERE status = 'ACTIVE'")
    List<Sprint> findActiveSprints();

    @Select("SELECT * FROM sprint WHERE status = 'COMPLETED'")
    List<Sprint> findCompletedSprints();

    @Select("SELECT * FROM sprint WHERE project_id = #{projectId}")
    List<Sprint> findByProjectId(Long projectId);
}