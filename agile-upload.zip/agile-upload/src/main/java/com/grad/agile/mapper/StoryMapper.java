package com.grad.agile.mapper;

import com.grad.agile.entity.Story;
import org.apache.ibatis.annotations.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Mapper
public interface StoryMapper {

    @Select("SELECT * FROM story WHERE sprint_id = #{sprintId}")
    List<Story> findBySprintId(Long sprintId);

    @Select("SELECT * FROM story")
    List<Story> findAll();

    @Select("SELECT * FROM story WHERE id = #{id}")
    Optional<Story> findById(Long id);

    @Insert("INSERT INTO story (project_id, sprint_id, title, story_point, status, description, priority, create_time) " +
            "VALUES (#{projectId}, #{sprintId}, #{title}, #{storyPoint}, #{status}, #{description}, #{priority}, #{createTime})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Story story);

    @Update("UPDATE story SET " +
            "project_id = #{projectId}, " +
            "sprint_id = #{sprintId}, " +
            "title = #{title}, " +
            "story_point = #{storyPoint}, " +
            "status = #{status}, " +
            "description = #{description}, " +
            "priority = #{priority} " +
            "WHERE id = #{id}")
    int update(Story story);

    @Delete("DELETE FROM story WHERE id = #{id}")
    int deleteById(Long id);

    @Update("UPDATE story SET " +
            "sprint_id = #{sprintId}, " +
            "project_id = (SELECT project_id FROM sprint WHERE id = #{sprintId}) " +
            "WHERE id = #{id}")
    int planToSprint(@Param("id") Long id, @Param("sprintId") Long sprintId);

    @Update("UPDATE story SET sprint_id = NULL WHERE id = #{id}")
    int moveToBacklog(@Param("id") Long id);

    @Select("SELECT * FROM story WHERE sprint_id IS NULL AND project_id = #{projectId}")
    List<Story> findBacklogByProjectId(@Param("projectId") Long projectId);

    /** 当前 sprint 总故事点 */
    @Select("SELECT COALESCE(SUM(story_point),0) FROM story WHERE sprint_id = #{sprintId}")
    Integer sumStoryPointBySprint(Long sprintId);

    /** 某天及之前已完成的故事点 */
    @Select("SELECT COALESCE(SUM(story_point),0) FROM story " +
            "WHERE sprint_id = #{sprintId} " +
            "AND status = 'DONE' " +
            "AND DATE(create_time) <= #{date}")
    Integer sumDoneStoryPointBefore(@Param("sprintId") Long sprintId, @Param("date") LocalDate date);
}