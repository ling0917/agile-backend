package com.grad.agile.mapper;

import com.grad.agile.entity.Task;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
@Mapper
public interface TaskMapper {

    // ==================== CRUD 操作 ====================

    @Insert("INSERT INTO task (title, description, priority, status, assignee_id, story_points, sprint_id, story_id, created_at, updated_at) " +
            "VALUES (#{title}, #{description}, #{priority}, #{status}, #{assigneeId}, #{storyPoints}, #{sprintId}, #{storyId}, #{createdAt}, #{updatedAt})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Task task);

    @Select("SELECT * FROM task")
    List<Task> findAll();

    @Select("SELECT * FROM task WHERE id = #{id}")
    Optional<Task> findById(Long id);

    @Update("UPDATE task SET " +
            "title = #{title}, " +
            "description = #{description}, " +
            "priority = #{priority}, " +
            "status = #{status}, " +
            "assignee_id = #{assigneeId}, " +
            "story_points = #{storyPoints}, " +
            "sprint_id = #{sprintId}, " +
            "story_id = #{storyId}, " +
            "updated_at = #{updatedAt} " +
            "WHERE id = #{id}")
    int update(Task task);

    @Delete("DELETE FROM task WHERE id = #{id}")
    int deleteById(Long id);

    // ==================== 条件查询 ====================

    @Select("SELECT * FROM task WHERE status = #{status}")
    List<Task> findByStatus(String status);

    @Select("SELECT * FROM task WHERE sprint_id = #{sprintId}")
    List<Task> findBySprintId(@Param("sprintId") Long sprintId);

    @Select("SELECT * FROM task WHERE sprint_id = #{sprintId} AND status = #{status}")
    List<Task> findBySprintIdAndStatus(@Param("sprintId") Long sprintId, @Param("status") String status);

    // ==================== 统计方法 ====================

    @Select("SELECT COUNT(*) FROM task WHERE sprint_id = #{sprintId}")
    Integer countBySprintId(@Param("sprintId") Long sprintId);

    @Select("SELECT COALESCE(SUM(story_points), 0) FROM task WHERE sprint_id = #{sprintId}")
    Integer sumStoryPointsBySprintId(@Param("sprintId") Long sprintId);

    @Select("SELECT COALESCE(SUM(story_points), 0) FROM task WHERE sprint_id = #{sprintId} AND status = 'DONE'")
    Integer sumCompletedStoryPointsBySprintId(@Param("sprintId") Long sprintId);

    @Select("SELECT COALESCE(SUM(story_points), 0) FROM task WHERE sprint_id = #{sprintId} AND status = 'TODO'")
    Integer sumTodoStoryPointsBySprintId(@Param("sprintId") Long sprintId);

    @Select("SELECT COALESCE(SUM(story_points), 0) FROM task WHERE sprint_id = #{sprintId} AND status = 'DOING'")
    Integer sumDoingStoryPointsBySprintId(@Param("sprintId") Long sprintId);

    // ==================== 状态更新 ====================

    @Update("UPDATE task SET status = #{status}, updated_at = NOW() WHERE id = #{id}")
    int updateStatus(@Param("id") Long id, @Param("status") String status);

    // ==================== 燃尽图相关方法 ====================

    /**
     * 获取每日完成的故事点统计
     * 返回格式: [{date: '2025-01-01', completedPoints: 5}, ...]
     */
    @Select("SELECT DATE(updated_at) AS date, SUM(story_points) AS completedPoints " +
            "FROM task WHERE sprint_id = #{sprintId} AND status = 'DONE' " +
            "GROUP BY DATE(updated_at) ORDER BY date")
    List<Map<String, Object>> findDailyCompletedStoryPoints(@Param("sprintId") Long sprintId);

    /**
     * 统计到指定日期为止已完成的故事点
     */
    @Select("SELECT COALESCE(SUM(story_points), 0) " +
            "FROM task " +
            "WHERE sprint_id = #{sprintId} " +
            "AND status = 'DONE' " +
            "AND DATE(updated_at) <= #{date}")
    Integer sumCompletedStoryPointsByDate(@Param("sprintId") Long sprintId, @Param("date") LocalDate date);

    // ==================== 其他查询方法 ====================

    /**
     * 根据条件和分页查询任务
     */
    @Select({"<script>",
            "SELECT * FROM task",
            "<where>",
            "  <if test='sprintId != null'> AND sprint_id = #{sprintId} </if>",
            "  <if test='status != null'> AND status = #{status} </if>",
            "  <if test='assigneeId != null'> AND assignee_id = #{assigneeId} </if>",
            "</where>",
            "ORDER BY created_at DESC",
            "<if test='limit != null'> LIMIT #{limit} </if>",
            "<if test='offset != null'> OFFSET #{offset} </if>",
            "</script>"})
    List<Task> findByCondition(@Param("sprintId") Long sprintId,
                               @Param("status") String status,
                               @Param("assigneeId") Long assigneeId,
                               @Param("limit") Integer limit,
                               @Param("offset") Integer offset);

    /**
     * 获取任务分配统计
     */
    @Select("SELECT assignee_id, COUNT(*) as task_count, SUM(story_points) as total_points " +
            "FROM task WHERE sprint_id = #{sprintId} GROUP BY assignee_id")
    List<Map<String, Object>> getTaskAssignmentStats(@Param("sprintId") Long sprintId);

    // ==================== Story 自动生成占位任务（用于 Backlog -> Sprint） ====================

    /** 某个 Story 下是否已经存在任务（不区分 sprint） */
    @Select("SELECT COUNT(*) FROM task WHERE story_id = #{storyId}")
    Integer countByStoryId(@Param("storyId") Long storyId);

    /** 重新规划时，把该 Story 下的任务绑定到新的 sprint */
    @Update("UPDATE task SET sprint_id = #{sprintId} WHERE story_id = #{storyId}")
    int updateSprintIdByStoryId(@Param("sprintId") Long sprintId, @Param("storyId") Long storyId);

    /** 取消规划时，把该 Story 下的任务从 sprint 移除（sprint_id 置空） */
    @Update("UPDATE task SET sprint_id = NULL WHERE story_id = #{storyId}")
    int clearSprintIdByStoryId(@Param("storyId") Long storyId);

    /** 清理旧占位任务标题前缀（仅更新匹配前缀的记录） */
    @Update("UPDATE task SET title = #{title} WHERE story_id = #{storyId} AND title LIKE '占位任务（来自故事）：%'")
    int normalizePlaceholderTitle(@Param("storyId") Long storyId, @Param("title") String title);
}