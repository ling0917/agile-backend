package com.grad.agile.mapper;

import com.grad.agile.entity.User;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserMapper {

    @Select("SELECT * FROM user")
    List<User> findAll();

    @Select("SELECT * FROM user WHERE id = #{id}")
    User findById(Long id);

    @Insert("INSERT INTO user(username, password, role, email, nickname) VALUES(#{username}, #{password}, #{role}, #{email}, #{nickname})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(User user);

    @Update("UPDATE user SET username=#{username}, password=#{password}, role=#{role}, email=#{email}, nickname=#{nickname} WHERE id=#{id}")
    int update(User user);

    @Update("UPDATE user SET nickname = #{nickname}, email = #{email} WHERE id = #{id}")
    int updateProfileFields(@Param("id") Long id, @Param("nickname") String nickname, @Param("email") String email);

    @Update("UPDATE user SET password = #{password} WHERE id = #{id}")
    int updatePasswordById(@Param("id") Long id, @Param("password") String password);

    @Delete("DELETE FROM user WHERE id = #{id}")
    int deleteById(Long id);
    @Select("SELECT * FROM user WHERE username = #{username}")
    User findByUsername(String username);

}