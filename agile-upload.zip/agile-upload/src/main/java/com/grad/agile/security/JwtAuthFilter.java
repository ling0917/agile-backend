package com.grad.agile.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.grad.agile.util.TokenUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {

    private final TokenUtil tokenUtil;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();

        // OPTIONS 预检直接放行（CORS）
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        // 明确公开的端点
        return "/"
                .equals(path)
                || "/index.html".equals(path)
                || "/auth/login".equals(path)
                || "/auth/register".equals(path)
                || "/auth/logout".equals(path)
                || "/auth/ping".equals(path)
                || "/test/public".equals(path)
                || "/error".equals(path)
                || "/favicon.ico".equals(path)
                // 模糊公共路径
                || path.startsWith("/public/")
                || path.startsWith("/static/")
                || path.startsWith("/assets/")
                || path.startsWith("/webjars/");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        String auth = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (auth == null || !auth.startsWith("Bearer ")) {
            writeUnauthorized(response, "缺少或非法的 Authorization Header");
            return;
        }

        String token = auth.substring("Bearer ".length()).trim();
        if (token.isEmpty() || !tokenUtil.validateToken(token)) {
            writeUnauthorized(response, "Token 无效或已过期");
            return;
        }

        // 把解析后的身份信息放到 request，供后续鉴权/业务使用
        String username = tokenUtil.getUsernameFromToken(token);
        String role = tokenUtil.getRoleFromToken(token);
        Long userId = tokenUtil.getUserIdFromToken(token);
        request.setAttribute("auth.username", username);
        request.setAttribute("auth.role", role);
        request.setAttribute("auth.userId", userId);

        filterChain.doFilter(request, response);
    }

    private void writeUnauthorized(HttpServletResponse response, String message) throws IOException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> body = new HashMap<>();
        body.put("success", false);
        body.put("code", 401);
        body.put("message", message);
        response.getWriter().write(objectMapper.writeValueAsString(body));
    }
}

