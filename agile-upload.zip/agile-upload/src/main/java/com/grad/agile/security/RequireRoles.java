package com.grad.agile.security;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface RequireRoles {
    /**
     * 允许访问的角色：PRODUCT_OWNER / SCRUM_MASTER / DEVELOPER
     */
    String[] value();
}

