// AuthService.java
package com.grad.agile.service;

import com.grad.agile.dto.LoginRequest;
import com.grad.agile.dto.LoginResponse;
import com.grad.agile.dto.RegisterRequest;
import com.grad.agile.entity.User;
import com.grad.agile.mapper.UserMapper;
import com.grad.agile.util.PasswordUtil;
import com.grad.agile.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private TokenUtil tokenUtil;

    @Autowired
    private PasswordUtil passwordUtil;

    public LoginResponse login(LoginRequest request) {
        // 1. 查找用户
        User user = userMapper.findByUsername(request.getUsername());
        if (user == null) {
            return new LoginResponse(null, null, null, null, "用户不存在");
        }

        // 2. 密码验证（BCrypt）
        if (!passwordUtil.matches(request.getPassword(), user.getPassword())) {
            return new LoginResponse(null, null, null, null, "密码错误");
        }

        // 3. 生成Token（3个参数）
        String token = tokenUtil.generateToken(user.getUsername(), user.getRole(), user.getId());

        // 4. 返回结果
        return new LoginResponse(
                token,
                user.getUsername(),
                user.getRole(),
                user.getEmail(),
                "登录成功"
        );
    }

    public LoginResponse register(RegisterRequest request) {
        if (request.getUsername() == null || request.getUsername().trim().isEmpty()) {
            return new LoginResponse(null, null, null, null, "用户名不能为空");
        }
        if (request.getPassword() == null || request.getPassword().trim().isEmpty()) {
            return new LoginResponse(null, null, null, null, "密码不能为空");
        }

        User existing = userMapper.findByUsername(request.getUsername());
        if (existing != null) {
            return new LoginResponse(null, null, null, null, "用户名已存在");
        }

        User user = new User();
        user.setUsername(request.getUsername().trim());
        user.setPassword(passwordUtil.hash(request.getPassword()));
        user.setRole(request.getRole() == null || request.getRole().trim().isEmpty()
                ? "DEVELOPER"
                : request.getRole().trim());
        user.setEmail(request.getEmail());
        if (request.getNickname() != null && !request.getNickname().trim().isEmpty()) {
            user.setNickname(request.getNickname().trim());
        } else {
            user.setNickname(request.getUsername().trim());
        }

        userMapper.insert(user);

        String token = tokenUtil.generateToken(user.getUsername(), user.getRole(), user.getId());
        return new LoginResponse(token, user.getUsername(), user.getRole(), user.getEmail(), "注册成功");
    }
}