package com.grad.agile.service;

import com.grad.agile.entity.Sprint;
import com.grad.agile.mapper.SprintMapper;
import com.grad.agile.mapper.TaskMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class MetricsService {
    private final SprintMapper sprintMapper;
    private final TaskMapper taskMapper;

    /**
     * Sprint 敏捷度量（最小版本）
     * - velocity: 完成故事点（DONE）
     * - completionRate: 完成率
     * - volatilityRate: 计划点数 vs 当前点数偏差比例（需要 sprint.total_story_points 有值）
     */
    public Map<String, Object> getSprintMetrics(Long sprintId) {
        Sprint sprint = sprintMapper.findById(sprintId)
                .orElseThrow(() -> new RuntimeException("迭代不存在，ID: " + sprintId));

        Integer totalTasks = taskMapper.countBySprintId(sprintId);
        Integer totalPoints = taskMapper.sumStoryPointsBySprintId(sprintId);
        Integer completedPoints = taskMapper.sumCompletedStoryPointsBySprintId(sprintId);

        int totalPointsVal = totalPoints != null ? totalPoints : 0;
        int completedPointsVal = completedPoints != null ? completedPoints : 0;

        double completionRate = totalPointsVal > 0 ? (completedPointsVal * 100.0) / totalPointsVal : 0.0;

        Integer plannedPoints = sprint.getTotalStoryPoints();
        Double volatilityRate = null;
        if (plannedPoints != null && plannedPoints > 0) {
            volatilityRate = Math.abs(totalPointsVal - plannedPoints) * 1.0 / plannedPoints;
        }

        Map<String, Object> metrics = new HashMap<>();
        metrics.put("sprintId", sprintId);
        metrics.put("sprintName", sprint.getName());
        metrics.put("status", sprint.getStatus());
        metrics.put("totalTasks", totalTasks != null ? totalTasks : 0);
        metrics.put("totalStoryPoints", totalPointsVal);
        metrics.put("completedStoryPoints", completedPointsVal);
        metrics.put("velocity", completedPointsVal);
        metrics.put("completionRate", String.format("%.1f%%", completionRate));
        metrics.put("plannedStoryPoints", plannedPoints);
        metrics.put("volatilityRate", volatilityRate); // 0.0 ~ n，前端可转百分比展示

        return metrics;
    }
}

