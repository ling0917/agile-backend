package com.grad.agile.service;

import com.grad.agile.entity.Sprint;
import com.grad.agile.dto.BurndownData;
import java.util.List;
import java.util.Map;

public interface SprintService {
    // 基础CRUD操作
    List<Sprint> getAllSprints();
    Sprint getSprintById(Long id);
    Sprint createSprint(Sprint sprint);
    Sprint updateSprint(Long id, Sprint sprint);
    void deleteSprint(Long id);

    // 查询操作
    List<Sprint> getSprintsByProjectId(Long projectId);

    // 燃尽图相关
    BurndownData getBurndownData(Long sprintId);

    // 迭代状态管理
    Sprint startSprint(Long id);
    Sprint completeSprint(Long id);

    // 状态查询
    List<Sprint> getActiveSprints();
    List<Sprint> getCompletedSprints();

    // 统计分析
    Map<String, Object> getSprintStatistics(Long sprintId);
}