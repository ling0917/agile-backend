package com.grad.agile.service;

import com.grad.agile.dto.TaskRequest;
import com.grad.agile.entity.Task;
import com.grad.agile.mapper.TaskMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class TaskService {
    private final TaskMapper taskMapper;

    /**
     * 创建任务
     */
    public Task createTask(TaskRequest request) {
        // 验证必要字段
        if (request.getTitle() == null || request.getTitle().trim().isEmpty()) {
            throw new RuntimeException("任务标题不能为空");
        }
        if (request.getSprintId() == null) {
            throw new RuntimeException("迭代ID不能为空");
        }

        // 创建任务对象
        Task task = new Task();
        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setPriority(request.getPriority() != null ? request.getPriority() : "MEDIUM");
        task.setStatus(request.getStatus() != null ? request.getStatus() : "TODO");
        task.setAssigneeId(request.getAssigneeId());
        task.setStoryPoints(request.getStoryPoints() != null ? request.getStoryPoints() : 0);
        task.setSprintId(request.getSprintId());
        task.setStoryId(request.getStoryId());
        task.setCreatedAt(LocalDateTime.now());
        task.setUpdatedAt(LocalDateTime.now());

        // 插入数据库
        taskMapper.insert(task);
        return task;
    }

    /**
     * 查询所有任务
     */
    public List<Task> getAllTasks() {
        return taskMapper.findAll();
    }

    /**
     * 根据ID查询任务
     */
    public Task getTaskById(Long id) {
        return taskMapper.findById(id)
                .orElseThrow(() -> new RuntimeException("任务不存在，ID: " + id));
    }

    /**
     * 更新任务
     */
    @Transactional
    public Task updateTask(Long id, TaskRequest request) {
        // 先查询任务是否存在
        Task task = getTaskById(id);

        // 验证必要字段
        if (request.getTitle() != null && request.getTitle().trim().isEmpty()) {
            throw new RuntimeException("任务标题不能为空");
        }

        // 更新任务信息
        if (request.getTitle() != null) {
            task.setTitle(request.getTitle());
        }
        if (request.getDescription() != null) {
            task.setDescription(request.getDescription());
        }
        if (request.getPriority() != null) {
            task.setPriority(request.getPriority());
        }
        if (request.getStatus() != null) {
            task.setStatus(request.getStatus());
        }
        if (request.getAssigneeId() != null) {
            task.setAssigneeId(request.getAssigneeId());
        }
        if (request.getStoryPoints() != null) {
            task.setStoryPoints(request.getStoryPoints());
        }
        if (request.getSprintId() != null) {
            task.setSprintId(request.getSprintId());
        }
        if (request.getStoryId() != null) {
            task.setStoryId(request.getStoryId());
        }

        task.setUpdatedAt(LocalDateTime.now());

        // 更新数据库
        taskMapper.update(task);
        return task;
    }

    /**
     * 删除任务
     */
    @Transactional
    public boolean deleteTask(Long id) {
        // 先检查任务是否存在
        Task task = getTaskById(id);

        // 删除任务
        int result = taskMapper.deleteById(id);
        return result > 0;
    }

    /**
     * 根据状态查询任务
     */
    public List<Task> getTasksByStatus(String status) {
        if (status == null || status.trim().isEmpty()) {
            throw new RuntimeException("状态参数不能为空");
        }
        return taskMapper.findByStatus(status);
    }

    /**
     * 根据迭代ID查询任务
     */
    public List<Task> getTasksBySprint(Long sprintId) {
        if (sprintId == null) {
            throw new RuntimeException("迭代ID不能为空");
        }
        return taskMapper.findBySprintId(sprintId);
    }

    /**
     * 更新任务状态
     */
    @Transactional
    public boolean updateTaskStatus(Long id, String status) {
        if (status == null || status.trim().isEmpty()) {
            throw new RuntimeException("状态不能为空");
        }

        // 验证状态值
        if (!status.equals("TODO") && !status.equals("DOING") && !status.equals("DONE")) {
            throw new RuntimeException("状态必须是 TODO、DOING 或 DONE");
        }

        int result = taskMapper.updateStatus(id, status);
        return result > 0;
    }

    /**
     * 统计迭代的任务信息
     */
    public Map<String, Object> getSprintTaskStats(Long sprintId) {
        if (sprintId == null) {
            throw new RuntimeException("迭代ID不能为空");
        }

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalTasks", taskMapper.countBySprintId(sprintId));
        stats.put("totalStoryPoints", taskMapper.sumStoryPointsBySprintId(sprintId));
        stats.put("completedStoryPoints", taskMapper.sumCompletedStoryPointsBySprintId(sprintId));
        stats.put("todoStoryPoints", taskMapper.sumTodoStoryPointsBySprintId(sprintId));
        stats.put("doingStoryPoints", taskMapper.sumDoingStoryPointsBySprintId(sprintId));

        return stats;
    }
}