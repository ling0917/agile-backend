package com.grad.agile.service;

import com.grad.agile.common.Result;
import com.grad.agile.common.ResultCode;
import com.grad.agile.dto.UpdateProfileRequest;
import com.grad.agile.dto.UserProfileResponse;
import com.grad.agile.entity.User;
import com.grad.agile.mapper.UserMapper;
import com.grad.agile.util.PasswordUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserProfileService {

    private final UserMapper userMapper;
    private final PasswordUtil passwordUtil;

    public Result<UserProfileResponse> getProfile(Long userId) {
        if (userId == null) {
            return Result.error(ResultCode.UNAUTHORIZED.getCode(), "未登录");
        }
        User u = userMapper.findById(userId);
        if (u == null) {
            return Result.error(ResultCode.NOT_FOUND.getCode(), "用户不存在");
        }
        return Result.success(toResponse(u));
    }

    @Transactional
    public Result<UserProfileResponse> updateProfile(Long userId, UpdateProfileRequest req) {
        if (userId == null) {
            return Result.error(ResultCode.UNAUTHORIZED.getCode(), "未登录");
        }
        User u = userMapper.findById(userId);
        if (u == null) {
            return Result.error(ResultCode.NOT_FOUND.getCode(), "用户不存在");
        }

        String nickname;
        if (req.getNickname() != null) {
            nickname = req.getNickname().trim().isEmpty() ? null : req.getNickname().trim();
        } else {
            nickname = u.getNickname();
        }
        String email;
        if (req.getEmail() != null) {
            email = req.getEmail().trim().isEmpty() ? null : req.getEmail().trim();
        } else {
            email = u.getEmail();
        }

        if (req.getNewPassword() != null && !req.getNewPassword().isBlank()) {
            if (req.getCurrentPassword() == null || req.getCurrentPassword().isBlank()) {
                return Result.error(ResultCode.BAD_REQUEST.getCode(), "修改密码需填写当前密码");
            }
            if (!passwordUtil.matches(req.getCurrentPassword(), u.getPassword())) {
                return Result.error(ResultCode.BAD_REQUEST.getCode(), "当前密码错误");
            }
            if (req.getNewPassword().length() < 6) {
                return Result.error(ResultCode.BAD_REQUEST.getCode(), "新密码至少 6 位");
            }
            userMapper.updatePasswordById(userId, passwordUtil.hash(req.getNewPassword().trim()));
        }

        userMapper.updateProfileFields(userId, nickname, email);
        User fresh = userMapper.findById(userId);
        return Result.success(toResponse(fresh));
    }

    private static UserProfileResponse toResponse(User u) {
        return new UserProfileResponse(
                u.getId(),
                u.getUsername(),
                u.getNickname(),
                u.getEmail(),
                u.getRole()
        );
    }
}
