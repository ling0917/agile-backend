package com.grad.agile.service.impl;

import com.grad.agile.entity.Sprint;
import com.grad.agile.entity.Task;
import com.grad.agile.dto.BurndownData;
import com.grad.agile.mapper.SprintMapper;
import com.grad.agile.mapper.TaskMapper;
import com.grad.agile.service.SprintService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
public class SprintServiceImpl implements SprintService {

    private final SprintMapper sprintMapper;
    private final TaskMapper taskMapper;

    @Override
    public List<Sprint> getAllSprints() {
        return sprintMapper.findAll();
    }

    @Override
    public Sprint getSprintById(Long id) {
        Optional<Sprint> sprint = sprintMapper.findById(id);
        return sprint.orElseThrow(() -> new RuntimeException("迭代不存在，ID: " + id));
    }

    @Override
    public Sprint createSprint(Sprint sprint) {
        // 验证必填字段
        validateSprintData(sprint);

        // 设置默认值
        if (sprint.getStatus() == null || sprint.getStatus().trim().isEmpty()) {
            sprint.setStatus("PLANNING");
        }

        sprint.setCreatedAt(LocalDateTime.now());
        sprint.setUpdatedAt(LocalDateTime.now());

        sprintMapper.insert(sprint);
        return sprint;
    }

    @Override
    public Sprint updateSprint(Long id, Sprint sprint) {
        Sprint existingSprint = getSprintById(id);

        // 更新可修改字段
        if (sprint.getName() != null) {
            existingSprint.setName(sprint.getName());
        }
        if (sprint.getGoal() != null) {
            existingSprint.setGoal(sprint.getGoal());
        }
        if (sprint.getStartDate() != null) {
            existingSprint.setStartDate(sprint.getStartDate());
        }
        if (sprint.getEndDate() != null) {
            existingSprint.setEndDate(sprint.getEndDate());
        }
        if (sprint.getStatus() != null) {
            existingSprint.setStatus(sprint.getStatus());
        }
        if (sprint.getProjectId() != null) {
            existingSprint.setProjectId(sprint.getProjectId());
        }
        if (sprint.getCapacity() != null) {
            existingSprint.setCapacity(sprint.getCapacity());
        }

        // 验证日期逻辑
        if (existingSprint.getStartDate() != null && existingSprint.getEndDate() != null) {
            if (existingSprint.getStartDate().isAfter(existingSprint.getEndDate())) {
                throw new RuntimeException("开始日期不能晚于结束日期");
            }
        }

        existingSprint.setUpdatedAt(LocalDateTime.now());
        sprintMapper.update(existingSprint);
        return existingSprint;
    }

    @Override
    public void deleteSprint(Long id) {
        getSprintById(id); // 确保迭代存在
        sprintMapper.deleteById(id);
    }

    @Override
    public List<Sprint> getSprintsByProjectId(Long projectId) {
        return sprintMapper.findByProjectId(projectId);
    }

    @Override
    public BurndownData getBurndownData(Long sprintId) {
        Sprint sprint = getSprintById(sprintId);

        // 如果迭代没有设置日期，返回空数据
        if (sprint.getStartDate() == null || sprint.getEndDate() == null) {
            return createEmptyBurndownData(sprint);
        }

        return calculateRealBurndownData(sprint);
    }

    @Override
    public Sprint startSprint(Long id) {
        Sprint sprint = getSprintById(id);
        sprint.setStatus("ACTIVE");
        sprint.setUpdatedAt(LocalDateTime.now());
        sprintMapper.update(sprint);
        return sprint;
    }

    @Override
    public Sprint completeSprint(Long id) {
        Sprint sprint = getSprintById(id);
        sprint.setStatus("COMPLETED");
        sprint.setUpdatedAt(LocalDateTime.now());
        sprintMapper.update(sprint);
        return sprint;
    }

    @Override
    public List<Sprint> getActiveSprints() {
        return sprintMapper.findByStatus("ACTIVE");
    }

    @Override
    public List<Sprint> getCompletedSprints() {
        return sprintMapper.findByStatus("COMPLETED");
    }

    @Override
    public Map<String, Object> getSprintStatistics(Long sprintId) {
        Sprint sprint = getSprintById(sprintId);

        Map<String, Object> stats = new HashMap<>();
        stats.put("sprintId", sprintId);
        stats.put("sprintName", sprint.getName());
        stats.put("status", sprint.getStatus());

        // 任务统计
        Integer totalTasks = taskMapper.countBySprintId(sprintId);
        Integer totalStoryPoints = taskMapper.sumStoryPointsBySprintId(sprintId);
        Integer completedStoryPoints = taskMapper.sumCompletedStoryPointsBySprintId(sprintId);
        Integer todoStoryPoints = taskMapper.sumTodoStoryPointsBySprintId(sprintId);
        Integer doingStoryPoints = taskMapper.sumDoingStoryPointsBySprintId(sprintId);

        stats.put("totalTasks", totalTasks != null ? totalTasks : 0);
        stats.put("totalStoryPoints", totalStoryPoints != null ? totalStoryPoints : 0);
        stats.put("completedStoryPoints", completedStoryPoints != null ? completedStoryPoints : 0);
        stats.put("todoStoryPoints", todoStoryPoints != null ? todoStoryPoints : 0);
        stats.put("doingStoryPoints", doingStoryPoints != null ? doingStoryPoints : 0);

        // 计算完成率
        double completionRate = 0.0;
        if (totalStoryPoints != null && totalStoryPoints > 0) {
            completionRate = (double) completedStoryPoints / totalStoryPoints * 100;
        }
        stats.put("completionRate", String.format("%.1f%%", completionRate));

        // 日期信息
        stats.put("startDate", sprint.getStartDate());
        stats.put("endDate", sprint.getEndDate());

        // 计算剩余天数
        if (sprint.getStartDate() != null && sprint.getEndDate() != null) {
            LocalDate today = LocalDate.now();
            long daysRemaining = ChronoUnit.DAYS.between(today, sprint.getEndDate());
            stats.put("daysRemaining", Math.max(0, daysRemaining));

            // 计算进度百分比
            long totalDays = ChronoUnit.DAYS.between(sprint.getStartDate(), sprint.getEndDate());
            long elapsedDays = ChronoUnit.DAYS.between(sprint.getStartDate(), today);
            double timeProgress = totalDays > 0 ? (double) elapsedDays / totalDays * 100 : 0;
            stats.put("timeProgress", String.format("%.1f%%", Math.min(Math.max(0, timeProgress), 100)));
        }

        return stats;
    }

    // ==================== 私有方法 ====================

    /**
     * 验证迭代数据
     */
    private void validateSprintData(Sprint sprint) {
        if (sprint.getName() == null || sprint.getName().trim().isEmpty()) {
            throw new RuntimeException("迭代名称不能为空");
        }
        if (sprint.getStartDate() == null) {
            throw new RuntimeException("开始日期不能为空");
        }
        if (sprint.getEndDate() == null) {
            throw new RuntimeException("结束日期不能为空");
        }
        if (sprint.getStartDate().isAfter(sprint.getEndDate())) {
            throw new RuntimeException("开始日期不能晚于结束日期");
        }
    }

    /**
     * 基于真实任务数据计算燃尽图
     */
    private BurndownData calculateRealBurndownData(Sprint sprint) {
        LocalDate startDate = sprint.getStartDate();
        LocalDate endDate = sprint.getEndDate();
        LocalDate currentDate = LocalDate.now();

        // 确保当前日期在迭代范围内
        if (currentDate.isBefore(startDate)) {
            currentDate = startDate;
        }
        if (currentDate.isAfter(endDate)) {
            currentDate = endDate;
        }

        // 计算迭代天数（含起止日）
        int totalDays = (int) ChronoUnit.DAYS.between(startDate, endDate) + 1;
        if (totalDays < 1) {
            totalDays = 1;
        }

        // 获取任务数据
        List<Task> tasks = taskMapper.findBySprintId(sprint.getId());
        Integer totalPointsObj = taskMapper.sumStoryPointsBySprintId(sprint.getId());
        int totalPoints = totalPointsObj != null ? totalPointsObj : 0;

        // 生成燃尽图数据：横轴为「整个迭代周期」的每一天，避免「迭代刚开始」时只有 1 个点
        // 未来日期的「实际剩余」用 null，前端折线断开，更符合燃尽图阅读习惯
        List<LocalDate> dates = new ArrayList<>();
        List<Integer> actualPoints = new ArrayList<>();
        List<Integer> idealPoints = new ArrayList<>();

        for (int i = 0; i < totalDays; i++) {
            LocalDate date = startDate.plusDays(i);
            dates.add(date);

            int idealPoint = calculateIdealPoints(totalPoints, i, totalDays);
            idealPoints.add(idealPoint);

            if (date.isAfter(currentDate)) {
                actualPoints.add(null);
            } else {
                actualPoints.add(calculateActualPointsForDate(tasks, date, totalPoints));
            }
        }

        // 计算当前完成情况
        Integer completedPointsObj = taskMapper.sumCompletedStoryPointsBySprintId(sprint.getId());
        int completedPoints = completedPointsObj != null ? completedPointsObj : 0;
        double completionRate = totalPoints > 0 ? (completedPoints * 100.0) / totalPoints : 0.0;

        // 创建燃尽图数据对象
        BurndownData burndownData = new BurndownData();
        burndownData.setSprintId(sprint.getId());
        burndownData.setSprintName(sprint.getName());
        burndownData.setDates(dates);
        burndownData.setActualRemainingPoints(actualPoints);
        burndownData.setIdealRemainingPoints(idealPoints);
        burndownData.setTotalPoints(totalPoints);
        burndownData.setCompletedPoints(completedPoints);
        burndownData.setCompletionRate(completionRate);

        return burndownData;
    }

    /**
     * 计算理想燃尽线（线性下降）
     */
    private int calculateIdealPoints(int totalPoints, int day, int totalDays) {
        if (totalDays <= 0) return totalPoints;
        int remaining = totalPoints - (totalPoints * day / totalDays);
        return Math.max(remaining, 0);
    }

    /**
     * 计算指定日期的实际剩余点数
     */
    private int calculateActualPointsForDate(List<Task> tasks, LocalDate date, int totalPoints) {
        if (tasks.isEmpty()) {
            return totalPoints;
        }

        int completedPoints = 0;

        for (Task task : tasks) {
            // 如果任务在指定日期之前已完成
            if ("DONE".equals(task.getStatus())) {
                if (task.getUpdatedAt() != null) {
                    LocalDate completedDate = task.getUpdatedAt().toLocalDate();
                    if (!completedDate.isAfter(date)) {
                        completedPoints += task.getStoryPoints() != null ? task.getStoryPoints() : 0;
                    }
                }
            }
        }

        int actualRemaining = totalPoints - completedPoints;
        return Math.max(actualRemaining, 0);
    }

    /**
     * 创建空的燃尽图数据
     */
    private BurndownData createEmptyBurndownData(Sprint sprint) {
        List<LocalDate> dates = new ArrayList<>();
        List<Integer> actualPoints = new ArrayList<>();
        List<Integer> idealPoints = new ArrayList<>();

        LocalDate today = LocalDate.now();
        dates.add(today);
        actualPoints.add(0);
        idealPoints.add(0);

        BurndownData burndownData = new BurndownData();
        burndownData.setSprintId(sprint.getId());
        burndownData.setSprintName(sprint.getName() != null ? sprint.getName() : "未知迭代");
        burndownData.setDates(dates);
        burndownData.setActualRemainingPoints(actualPoints);
        burndownData.setIdealRemainingPoints(idealPoints);
        burndownData.setTotalPoints(0);
        burndownData.setCompletedPoints(0);
        burndownData.setCompletionRate(0.0);

        return burndownData;
    }
}