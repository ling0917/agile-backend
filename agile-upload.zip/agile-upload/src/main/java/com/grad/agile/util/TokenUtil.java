package com.grad.agile.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;
import java.util.Optional;

@Component
public class TokenUtil {

    private final Key signingKey;
    private final long expirationMillis;

    public TokenUtil(
            @Value("${jwt.secret}") String base64Secret,
            @Value("${jwt.expiration-millis:86400000}") long expirationMillis
    ) {
        this.signingKey = Keys.hmacShaKeyFor(Decoders.BASE64.decode(base64Secret));
        this.expirationMillis = expirationMillis;
    }

    public String generateToken(String username, String role, Long userId) {
        Date now = new Date();
        Date exp = new Date(now.getTime() + expirationMillis);

        return Jwts.builder()
                .setSubject(username)
                .claim("role", role)
                .claim("userId", userId)
                .setIssuedAt(now)
                .setExpiration(exp)
                .signWith(signingKey, SignatureAlgorithm.HS256)
                .compact();
    }


    // 验证Token
    public boolean validateToken(String token) {
        try {
            parse(token);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            return false;
        }
    }

    public String getUsernameFromToken(String token) {
        return getClaim(token, Claims::getSubject).orElse(null);
    }

    public String getRoleFromToken(String token) {
        return getClaim(token, c -> c.get("role", String.class)).orElse(null);
    }

    public Long getUserIdFromToken(String token) {
        return getClaim(token, c -> {
            Object raw = c.get("userId");
            if (raw instanceof Number n) {
                return n.longValue();
            }
            if (raw instanceof String s) {
                try {
                    return Long.parseLong(s);
                } catch (NumberFormatException ignored) {
                    return null;
                }
            }
            return null;
        }).orElse(null);
    }

    private Jws<Claims> parse(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(signingKey)
                .build()
                .parseClaimsJws(token);
    }

    private <T> Optional<T> getClaim(String token, java.util.function.Function<Claims, T> extractor) {
        try {
            Claims claims = parse(token).getBody();
            return Optional.ofNullable(extractor.apply(claims));
        } catch (JwtException | IllegalArgumentException e) {
            return Optional.empty();
        }
    }
}