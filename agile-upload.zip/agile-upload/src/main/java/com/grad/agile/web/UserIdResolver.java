package com.grad.agile.web;

import com.grad.agile.util.TokenUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * 从拦截器/JWT 过滤器写入的 request 属性或 Authorization 头解析当前用户 ID。
 */
@Component
@RequiredArgsConstructor
public class UserIdResolver {

    private final TokenUtil tokenUtil;

    public Long resolve(HttpServletRequest request) {
        Object raw = request.getAttribute("auth.userId");
        if (raw instanceof Number n) {
            return n.longValue();
        }
        String auth = request.getHeader("Authorization");
        if (auth != null && auth.startsWith("Bearer ")) {
            String token = auth.substring(7).trim();
            if (!token.isEmpty() && tokenUtil.validateToken(token)) {
                return tokenUtil.getUserIdFromToken(token);
            }
        }
        return null;
    }
}
